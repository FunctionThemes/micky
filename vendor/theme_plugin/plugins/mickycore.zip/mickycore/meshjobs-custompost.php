<?php
/*********** service ************/
add_action( 'init', 'meshjobs_gallery' );
function meshjobs_gallery(){
	 $labels = array( 
        'name' => _x( 'Gallery', 'Gallery', 'meshjobs' ),
        'singular_name' => _x( 'Gallery', 'Gallery', 'meshjobs' ),
        'add_new' => _x( 'Add New', 'Gallery', 'meshjobs' ),
        'add_new_item' => _x( 'Add New Gallery Member', 'Gallery', 'meshjobs' ),
        'edit_item' => _x( 'Edit Gallery', 'Gallery', 'meshjobs' ),
        'new_item' => _x( 'New Gallery', 'Gallery', 'meshjobs' ),
        'view_item' => _x( 'View Gallery', 'Gallery', 'meshjobs' ),
        'search_items' => _x( 'Search Gallery', 'Gallery', 'meshjobs' ),
        'not_found' => _x( 'No Gallery found', 'Gallery', 'meshjobs' ),
        'not_found_in_trash' => _x( 'No Gallery member found in Trash', 'Gallery', 'meshjobs' ),
        'parent_item_colon' => _x( 'Parent Gallery:', 'Gallery', 'meshjobs' ),
        'menu_name' => _x( 'Gallery ', 'Gallery', 'meshjobs' ),
		'all_items' => _x( 'All Gallery ', 'Gallery', 'meshjobs' ),
		'search_items' => _x( 'No Gallery found', 'Gallery', 'meshjobs' )
    );
	$args = array( 
        'labels' => $labels,
        'hierarchical' => false,
        'supports' => array( 'title', 'editor' ,'thumbnail'),
        'public' => true, 
        'show_ui' => true,
        'show_in_nav_menus' => false,
        'publicly_queryable' => true,
        'exclude_from_search' => true,
        'has_archive' => true,
        'query_var' => true,
        'can_export' => true,
        'rewrite' => false,
		'menu_icon' => 'dashicons-images-alt2',
    );
	register_post_type( 'gallery', $args );
}
if(!function_exists('gallery_taxonomies')){
	function gallery_taxonomies() {
		register_taxonomy("gallery_categories", array("gallery"), array("hierarchical" => true, "label" => "Categories", "singular_label" => "Category", "rewrite" => true));
	} 
	// add taxonomies to categorize different custom post types
	add_action( 'init', 'gallery_taxonomies', 0);
}
/*********** team ************/
add_action( 'init', 'meshjobs_team' );
function meshjobs_team(){
	 $labels = array( 
        'name' => _x( 'Team', 'Team', 'meshjobs' ),
        'singular_name' => _x( 'Team', 'Team', 'meshjobs' ),
        'add_new' => _x( 'Add New', 'Team', 'meshjobs' ),
        'add_new_item' => _x( 'Add New Team Member', 'Team', 'meshjobs' ),
        'edit_item' => _x( 'Edit Team', 'Team', 'meshjobs' ),
        'new_item' => _x( 'New Team', 'Team', 'meshjobs' ),
        'view_item' => _x( 'View Team', 'Team', 'meshjobs' ),
        'search_items' => _x( 'Search Team', 'Team', 'meshjobs' ),
        'not_found' => _x( 'No Team found', 'Team', 'meshjobs' ),
        'not_found_in_trash' => _x( 'No Team member found in Trash', 'Team', 'meshjobs' ),
        'parent_item_colon' => _x( 'Parent Team:', 'Team', 'meshjobs' ),
        'menu_name' => _x( 'Team ', 'Team', 'meshjobs' ),
		'all_items' => _x( 'All Team ', 'Team', 'meshjobs' ),
		'search_items' => _x( 'No Team found', 'Team', 'meshjobs' )
    );
	$args = array( 
        'labels' => $labels,
        'hierarchical' => false,
        'supports' => array( 'title'),
        'public' => true,  
        'show_ui' => true,
        'show_in_nav_menus' => false,
        'publicly_queryable' => true,
        'exclude_from_search' => true,
        'has_archive' => true,
        'query_var' => true,
        'can_export' => true,
        'rewrite' => false,
		'menu_icon' => 'dashicons-businessman',
    );
	register_post_type( 'team', $args );
}
if(!function_exists('team_taxonomies')){
	function team_taxonomies() {
		register_taxonomy("team_categories", array("team"), array("hierarchical" => true, "label" => "Categories", "singular_label" => "Category", "rewrite" => true));
	} 
	// add taxonomies to categorize different custom post types
	add_action( 'init', 'team_taxonomies', 0);
}
?>