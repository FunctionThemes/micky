<?php
$prefix = 'meshjobs_';
/*===========	Start Post MetaBox   =========*/
$post_option_meta = array(
    'id' => 'section-post-meta',
    'title' => __('Post Meta Setting','meshjobs'),
    'page' => 'post',
    'context' => 'normal',
    'priority' => 'high',
    'fields' => array(
		array(
            'name' => __('Choose Sidebar Position For This Section', 'meshjobs'),
            'desc' => '',
            'id' => $prefix.'post_sidebarposition',
            'type' => 'sidebarradio',
            'std' => 'full',
			'option' => array(
					'full' => PLUGIN_PATH.'/images/1col.png',
					'left' => PLUGIN_PATH.'/images/2cl.png',
					'right' => PLUGIN_PATH.'/images/2cr.png'
				)
        ),
		array(
            'name' => 'Upload Image or Video',
            'desc' => '',
            'id' => $prefix.'postimg_video', 
            'type' => 'select',
            'std' => 'Images',
            'options' => array('Images', 'Video' ),
        ),
		array(
            'name' => 'Upload Images',
            'desc' => '',
            'id' => $prefix.'postmul_imgs',
            'type' => 'mul_img',
			'std' => ''
        ),
        array(
            'name' => 'Enter URL Vimeo Or Youtube',
            'desc' => '',
            'id' => $prefix.'posturl_vimeo_youtube',
            'type' => 'text',
			'std' => ''
        ),
		array(
            'name' => __('Upload Overlay Image', 'meshjobs'),
            'desc' => __('Choose Vimeo Or Youtube Overlay Image.', 'meshjobs'),
            'id' => $prefix.'postvideo_overlay',
            "type" => "text",
            'std' => ''
        ),
		array(
            'name' => '',
            'desc' => '',
            'id' => $prefix.'video_overlay_button',
            'type' => 'button',
            'std' => 'Browse'
        ),
        array(
            'name' => '',
            'desc' => '',
            'id' => $prefix.'postauthor_clear_fields',
            'type' => 'button-clear',
            'std' => 'Clear Meta'
        )
	) 
);
// create boxes for team
add_action('admin_menu', 'add_post_meta_boxes');
if(!function_exists('add_post_meta_boxes')){	
	function add_post_meta_boxes()
	{
		global  $post_option_meta;
		add_meta_box($post_option_meta['id'], $post_option_meta['title'], 'show_post_options', $post_option_meta['page'], $post_option_meta['context'], $post_option_meta['priority']);
	}
}
if(!function_exists('show_post_options')){	
	function show_post_options()
	{
		global $post_option_meta, $post;
		// Use nonce for verification
		echo '<input type="hidden" name="meta_box_nonce" value="', wp_create_nonce(basename(__FILE__)), '" />';
		echo '<table class="form-table">';
		foreach ($post_option_meta['fields'] as $field) {
			// get current post meta data
			$meta = get_post_meta($post->ID, $field['id'], true);
			switch ($field['type']) {
				case 'sidebarradio':
					echo '<tr>',
					'<th style="width:25%"><label for="', $field['id'], '"><strong>', $field['name'], '</strong><span style=" display:block; color:#999; margin:5px 0 0 0; line-height: 18px;">' . $field['desc'] . '</span></label></th>',
					'<td>';
					if(empty($meta)){
						$meta = 'full';
					}
					foreach($field['option'] as $k=>$v){
						echo '<div class="', ($meta == $k) ? 'meshjobs_chooseborder1 '
						: '' ,'meshjobs-select-sidebar1">
						<div style="display:none;">
						<input type="radio" value="'.$k.'" ',($meta == $k) ? 'checked'
						: '','  name="'.$field['id'].'" ></div>';
						echo '<img src="'.$v.'" alt=""></div>';
					}
				break;
				case 'text':
					echo '<tr id="rs_', $field['id'], '">',
					'<th style="width:25%"><label for="', $field['id'], '"><strong>', $field['name'], '</strong><span style=" display:block; color:#999; margin:5px 0 0 0; line-height: 18px;">' . $field['desc'] . '</span></label></th>',
					'<td>';
					echo '<input type="text" name="', $field['id'], '" id="', $field['id'], '" value="', $meta ? $meta
						: stripslashes(htmlspecialchars(($field['std']), ENT_QUOTES)), '" size="30" style="width:75%; margin-right: 20px; float:left;" />';
                break;
				case 'button':
					echo '<input style="float: left;" type="button" class="button meshjobs_upload_image_button" name="', $field['id'], '" id="', $field['id'], '" value="Browse" />';
					echo     '</td>',
					'</tr>';
                break;
				case 'select':
                echo '<tr id="rs_', $field['id'], '">',
                '<th style="width:25%"><label for="', $field['id'], '"><strong>', $field['name'], '</strong><span style=" display:block; color:#999; margin:5px 0 0 0; line-height: 18px;">' . $field['desc'] . '</span></label></th>',
                '<td>';
                echo'<select name="' . $field['id'] . '" id="' . $field['id'] . '">';
                foreach ($field['options'] as $option) {
                    echo'<option';
                    if ($meta == $option) {
                        echo ' selected="selected"';
                    }
                    echo'>' . $option . '</option>';
                }
                echo'</select>';
				break;
				case 'mul_img':
					$id = $field['id']; 	 
					$svalue = ($meta ? $meta:''); 					 
					$multiple = true; 					 
					$width = null; 					 
					$height = null; 
					echo '<tr id="rs_', $field['id'], '">',
					'<th style="width:25%"><label for="', $field['id'], '"><strong>', $field['name'], '</strong><span style=" display:block; color:#999; margin:5px 0 0 0; line-height: 18px;">' . $field['desc'] . '</span></label></th>',
					'<td>';
					echo '<input type="hidden" name="',$id,'" id="',$id,'" value="', $svalue,'" />  ';
?> 
				<div class="plupload-upload-uic hide-if-no-js <?php if ($multiple): ?>plupload-upload-uic-multiple<?php endif; ?>" id="<?php echo $id; ?>plupload-upload-ui">  
					<input id="<?php echo $id; ?>plupload-browse-button" type="button" value="<?php esc_attr_e('Select Files'); ?>" class="button" />
					<span class="ajaxnonceplu" id="ajaxnonceplu<?php echo wp_create_nonce($id . 'pluploadan'); ?>"></span>
					<?php if ($width && $height): ?>
							<span class="plupload-resize"></span><span class="plupload-width" id="plupload-width<?php echo $width; ?>"></span>
							<span class="plupload-height" id="plupload-height<?php echo $height; ?>"></span>
					<?php endif; ?>
					<div class="filelist"></div>
				</div>  
				<div class="plupload-thumbs <?php if ($multiple): ?>plupload-thumbs-multiple<?php endif; ?>" id="<?php echo $id; ?>plupload-thumbs">  
				</div>  
				<div class="clear"></div>  
			<?php
				break;
				case 'video_url':
					$video = get_post_meta($post->ID,'meshjobs_posturl_vimeo_youtube',true);
					echo '<tr id="rs_', $field['id'], '"',
					(empty($video)) ? ' style="display:none;"' : '',' >',
					'<th style="width:25%"><label for="', $field['id'], '"><strong>', $field['name'], '</strong><span style=" display:block; color:#999; margin:5px 0 0 0; line-height: 18px;">' . $field['desc'] . '</span></label></th>',
					'<td>';
					echo '<input type="text" name="', $field['id'], '" id="', $field['id'], '" value="', $meta ? stripslashes(htmlspecialchars(($meta), ENT_QUOTES))
						: stripslashes(htmlspecialchars(($field['std']), ENT_QUOTES)), '" size="30" style="width:75%; margin-right: 20px; float:left;" />';
                break;
                case 'button-clear':
                echo '<tr><td colspan="2"><input style="float: right;" type="button" class="button" name="', $field['id'], '" id="', $field['id'], '" value="Clear Meta" />';
                ?>
                <script type="text/javascript">
                    jQuery(document).ready(function($){
                        $('#<?php echo esc_js( $field['id'] ); ?>').click(function(){
                            if(confirm("Are you sure you want to clear fields?")){
                                 $('#<?php echo esc_js ( $team_option_meta['id'] ); ?> input[type="text"]').val('');
                             }
                        });
                    });
                </script>
                <?php
                echo     '</td>',
                '</tr>';
                break;
			}
		}
		echo '</table>';
	}
}
add_action('save_post', 'post_save_options');
if(!function_exists('post_save_options')){	
	function post_save_options($post_id)
	{	
		global $post_option_meta;
		$new = '';
		// verify nonce
		if (isset($_POST['meta_box_nonce']) && !wp_verify_nonce($_POST['meta_box_nonce'], basename(__FILE__))) {
			return $post_id;
		}
		// check autosave
		if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
			return $post_id;
		}
		if (defined('DOING_AJAX') && DOING_AJAX)
			return;
		// check permissions
		if (isset($_POST['post_type']) && 'page' == $_POST['post_type']) {
			if (!current_user_can('edit_page', $post_id)) {
				return $post_id;
			}
		} elseif (!current_user_can('edit_post', $post_id)) {
			return $post_id;
		}
		foreach ($post_option_meta['fields'] as $field) {
			$old = get_post_meta($post_id, $field['id'], true);
			if (isset($_POST[$field['id']])) {
				 $new = $_POST[$field['id']];
			}
			if ($new && $new != $old) {
				update_post_meta($post_id, $field['id'], $new);
			} elseif ('' == $new && $old) {
				delete_post_meta($post_id, $field['id'], $old);
			}
		}
	}
}
/*********=========	End Post MetaBox   =========*********/
/*===========	Start Page MetaBox   =========*/
$page_option_meta = array(
    'id' => 'section-page-meta',
    'title' => __('Page Meta Setting','meshjobs'),
    'page' => 'page',
    'context' => 'normal',
    'priority' => 'high',
    'fields' => array(
	    array(
            'name' => __('Choose Sidebar Position For This Page', 'meshjobs'),
            'desc' => '',
            'id' => $prefix.'page_sidebarposition',
            'type' => 'sidebarradio',
            'std' => 'full',
			'option' => array(
					'full' => PLUGIN_PATH.'/images/1col.png',
					'left' => PLUGIN_PATH.'/images/2cl.png',
					'right' => PLUGIN_PATH.'/images/2cr.png'
				)
        ),
		array(
		    'name' => __('Remove Header Bottom Space', 'meshjobs'),
            'desc' => __('', 'meshjobs'),
            'id' => $prefix.'header_margin',
            "type" => "social",
            'val' => 'checked' 
        ),
	) 
);
// create boxes for team
add_action('admin_menu', 'add_page_meta_boxes');
if(!function_exists('add_page_meta_boxes')){	
	function add_page_meta_boxes()
	{
		global  $page_option_meta;
		add_meta_box($page_option_meta['id'], $page_option_meta['title'], 'show_page_options', $page_option_meta['page'], $page_option_meta['context'], $page_option_meta['priority']);
	}
}
if(!function_exists('show_page_options')){	
	function show_page_options()
	{
		global $page_option_meta, $post;
		// Use nonce for verification
		echo '<input type="hidden" name="meta_box_nonce" value="', wp_create_nonce(basename(__FILE__)), '" />';
		echo '<table class="form-table">';
		foreach ($page_option_meta['fields'] as $field) {
			// get current post meta data
			$meta = get_post_meta($post->ID, $field['id'], true);
			switch ($field['type']) {
				case 'sidebarradio':
				echo '<tr>',
				'<th style="width:25%"><label for="', $field['id'], '"><strong>', $field['name'], '</strong><span style=" display:block; color:#999; margin:5px 0 0 0; line-height: 18px;">' . $field['desc'] . '</span></label></th>',
				'<td>';
				if(empty($meta)){
					$meta = 'full';
				}
				foreach($field['option'] as $k=>$v){
					echo '<div class="', ($meta == $k) ? 'meshjobs_chooseborder '
					: '' ,'meshjobs-select-sidebar">
					<div style="display:none;">
					<input type="radio" value="'.$k.'" ',($meta == $k) ? 'checked'
					: '','  name="'.$field['id'].'" ></div>';
					echo '<img src="'.$v.'" alt=""></div>';
				}
				break;
				case 'social':
				echo '<tr>',
                '<th style="width:25%"><label for="', $field['id'], '"><strong>', $field['name'], '</strong><span style=" display:block; color:#999; margin:5px 0 0 0; line-height: 18px;">' . $field['desc'] . '</span></label></th>',
                '<td>';
                echo '<input type="checkbox" name="', $field['id'], '" id="', $field['id'], '" value="',$field['val'] , '" ';
				if(isset($meta) && $meta == $field['val']){
					echo ' checked ';
				}
				echo '/>';
                break;
				
			}
		}
		echo '</table>';
	}
}
add_action('save_post', 'page_save_options');
if(!function_exists('page_save_options')){	
	function page_save_options($post_id)
	{	
		global $page_option_meta;
		$new = '';
		// verify nonce
		if (isset($_POST['meta_box_nonce']) && !wp_verify_nonce($_POST['meta_box_nonce'], basename(__FILE__))) {
			return $post_id;
		}
		// check autosave
		if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
			return $post_id;
		}
		if (defined('DOING_AJAX') && DOING_AJAX)
			return;
		// check permissions
		if (isset($_POST['post_type']) && 'page' == $_POST['post_type']) {
			if (!current_user_can('edit_page', $post_id)) {
				return $post_id;
			}
		} elseif (!current_user_can('edit_post', $post_id)) {
			return $post_id;
		}
		foreach ($page_option_meta['fields'] as $field) {
			$old = get_post_meta($post_id, $field['id'], true);
			if (isset($_POST[$field['id']])) {
				 $new = $_POST[$field['id']];
			}
			if ($new && $new != $old) {
				update_post_meta($post_id, $field['id'], $new);
			} elseif ('' == $new && $old) {
				delete_post_meta($post_id, $field['id'], $old);
			}
		}
	}
}
/*********=========	End Page MetaBox   =========*********/
/*********========= Start Team Metabox    =========*********/
$team_option_meta = array( 
    'id' => 'team-meta',
    'title' => __('Team home section setting','meshjobs'),
    'page' => 'team',
    'context' => 'normal',
    'priority' => 'high',
    'fields' => array(
        array(
            'name' => __('Member name', 'meshjobs'),
            'desc' => __('Enter member name', 'meshjobs'),
            'id' => $prefix.'team_name',
            "type" => "text",
            'std' => ''
        ),
		array(
            'name' => __('Description', 'meshjobs'),
            'desc' => __('', 'meshjobs'),
            'id' => $prefix.'team_decription',
            "type" => "textarea",
            'std' => ''
        ),
        array(
            'name' => __('Member photo', 'meshjobs'),
            'desc' => __('Upload a member photo image (Must use 400x400 or above).', 'meshjobs'), 
            'id' => $prefix.'team_image',
            "type" => "text",
            'std' => ''
        ),
		array(
            'name' => '',
            'desc' => '',
            'id' => $prefix.'team_image_button',
            'type' => 'button',
            'std' => 'Browse'  
        ),
        array(
            'name' => __('Facebook link', 'meshjobs'),
            'desc' => __('Enter Facebook link', 'meshjobs'),
            'id' => $prefix.'team_Facebook',
            "type" => "text",
            'std' => '' 
        ),
		array(
            'id' => $prefix.'team_Facebook_show',
            "type" => "social",
            'val' => 'facebook' 
        ),
        array(
            'name' => __('Twitter link', 'meshjobs'),
            'desc' => __('Enter Twitter link', 'meshjobs'),
            'id' => $prefix.'team_Twitter',
            "type" => "text",
            'std' => ''
        ),
		array(
            'id' => $prefix.'team_Twitter_show',
            "type" => "social",
            'val' => 'twitter' 
        ),
		array(
            'name' => __('Youtube link', 'meshjobs'),
            'desc' => __('Enter Youtube link', 'meshjobs'),
            'id' => $prefix.'team_youtube',
            "type" => "text",
            'std' => ''
        ),
		array(
            'id' => $prefix.'team_youtube_show',
            "type" => "social",
            'val' => 'youtube' 
        ),
		array(
            'name' => __('Linkedin link', 'meshjobs'),
            'desc' => __('Enter Linkedin link', 'meshjobs'),
            'id' => $prefix.'team_linkedin',
            "type" => "text",
            'std' => ''
        ),
		array(
            'id' => $prefix.'team_linkedin_show',
            "type" => "social",
            'val' => 'Linkedin' 
        ),
		array(
            'name' => __('Google plus link', 'meshjobs'),
            'desc' => __('Enter Google plus link', 'meshjobs'),
            'id' => $prefix.'team_googleplus',
            "type" => "text",
            'std' => ''
        ),
		array(
            'id' => $prefix.'team_googleplus_show',
            "type" => "social",
            'val' => 'Googleplus' 
        ),
		array(
            'name' => __('Dribbble link', 'meshjobs'),
            'desc' => __('Enter Dribbble link', 'meshjobs'),
            'id' => $prefix.'team_dribbble',
            "type" => "text",
            'std' => ''
        ),
		array(
            'id' => $prefix.'team_dribbble_show',
            "type" => "social",
            'val' => 'dribbble' 
        ),
		array(
            'name' => __('Behance link', 'meshjobs'),
            'desc' => __('Enter Behance link', 'meshjobs'),
            'id' => $prefix.'team_behance',
            "type" => "text",
            'std' => ''
        ),
		array(
            'id' => $prefix.'team_behance_show',
            "type" => "social",
            'val' => 'Behance' 
        ),
        array(
            'name' => '',
            'desc' => '',
            'id' => $prefix.'team_clear_fields',
            'type' => 'button-clear',
            'std' => 'Clear Meta'
        )
    )
);
// create boxes for team
add_action('admin_menu', 'add_team_meta_boxes');
function add_team_meta_boxes()
{
    global  $team_option_meta;
    add_meta_box($team_option_meta['id'], $team_option_meta['title'], 'show_team_options', $team_option_meta['page'], $team_option_meta['context'], $team_option_meta['priority']);
}
function show_team_options()
{
    global $team_option_meta, $post;
    // Use nonce for verification
    echo '<input type="hidden" name="meta_box_nonce" value="', wp_create_nonce(basename(__FILE__)), '" />';
    echo '<table class="form-table">';
    foreach ($team_option_meta['fields'] as $field) {
        // get current post meta data
        $meta = get_post_meta($post->ID, $field['id'], true);
        switch ($field['type']) {
            case 'text':
                echo '<tr>',
                '<th style="width:25%"><label for="', $field['id'], '"><strong>', $field['name'], '</strong><span style=" display:block; color:#999; margin:5px 0 0 0; line-height: 18px;">' . $field['desc'] . '</span></label></th>',
                '<td>';
                echo '<input type="text" name="', $field['id'], '" id="', $field['id'], '" value="', $meta ? $meta
                    : stripslashes(htmlspecialchars(($field['std']), ENT_QUOTES)), '" size="30" style="width:75%; margin-right: 20px; float:left;" />';
                break;
            case 'button':
					echo '<input style="float: left;" type="button" class="button meshjobs_upload_image_button" name="', $field['id'], '" id="', $field['id'], '" value="Browse" />';
					echo     '</td>',
					'</tr>';
                break;
			case 'social':
                echo '<input type="checkbox" name="', $field['id'], '" id="', $field['id'], '" value="',$field['val'] , '" ';
				if(isset($meta) && $meta == $field['val']){
					echo ' checked ';
				}
				echo '/>';
                break;
            case 'button-clear':
                echo '<tr><td colspan="2"><input style="float: right;" type="button" class="button" name="', $field['id'], '" id="', $field['id'], '" value="Clear Meta" />';
                ?>
                <script type="text/javascript">
                    jQuery(document).ready(function($){
                        $('#<?php echo esc_js( $field['id'] ); ?>').click(function(){
                            if(confirm("Are you sure you want to clear fields?")){
                                 $('#<?php echo esc_js ( $team_option_meta['id'] ); ?> input[type="text"]').val('');
                             }
                        });
                    });
                </script>
                <?php
                echo     '</td>',
                '</tr>';
                break;
            case 'select':
                echo '<tr>',
                '<th style="width:25%"><label for="', $field['id'], '"><strong>', $field['name'], '</strong><span style=" display:block; color:#999; margin:5px 0 0 0; line-height: 18px;">' . $field['desc'] . '</span></label></th>',
                '<td>';
                echo'<select name="' . $field['id'] . '">';
                foreach ($field['options'] as $option) {
                    echo'<option';
                    if ($meta == $option) {
                        echo ' selected="selected"';
                    }
                    echo'>' . $option . '</option>';
                }
                echo'</select>';
                break;
            case 'select-custom':
                echo '<tr>',
                '<th style="width:25%"><label for="', $field['id'], '"><strong>', $field['name'], '</strong><span style=" display:block; color:#999; margin:5px 0 0 0; line-height: 18px;">' . $field['desc'] . '</span></label></th>',
                '<td>';
                echo'<select name="' . $field['id'] . '">';
                foreach ($field['options'] as $key => $option) {
                    echo'<option';
                    if ($meta == $key) {
                        echo ' selected="selected"';
                    }
                    echo' value="'.$key.'">' . $option . '</option>';
                }
                echo'</select>';
                break;
			case 'textarea':
                echo '<tr>',
                '<th style="width:25%"><label for="', $field['id'], '"><strong>', $field['name'], '</strong><span style=" display:block; color:#999; margin:5px 0 0 0; line-height: 18px;">' . $field['desc'] . '</span></label></th>',
                '<td>';
				$args = array(
					'textarea_rows' => 5,
					'media_buttons' => false,
					'teeny' => true,
					'quicktags' => false
				);
				wp_editor($meta ? $meta : stripslashes(htmlspecialchars(($field['std']), ENT_QUOTES)), $field['id'],$args);
                break;
        }
    }
    echo '</table>';
}
add_action('save_post', 'team_save_options');
// save team metadata
function team_save_options($post_id)
{
    global $team_option_meta;
    $new = '';
    // verify nonce
    if (isset($_POST['meta_box_nonce']) && !wp_verify_nonce($_POST['meta_box_nonce'], basename(__FILE__))) {
        return $post_id;
    }
    // check autosave
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
        return $post_id;
    }
    if (defined('DOING_AJAX') && DOING_AJAX)
        return;
    // check permissions
    if (isset($_POST['post_type']) && 'page' == $_POST['post_type']) {
        if (!current_user_can('edit_page', $post_id)) {
            return $post_id;
        }
    } elseif (!current_user_can('edit_post', $post_id)) {
        return $post_id;
    }
 
    foreach ($team_option_meta['fields'] as $field) {
        $old = get_post_meta($post_id, $field['id'], true);
        if (isset($_POST[$field['id']])) {
            $new = $_POST[$field['id']];
        }
        if ($new && $new != $old) {
            update_post_meta($post_id, $field['id'], $new);
        } elseif ('' == $new && $old) {
            delete_post_meta($post_id, $field['id'], $old);
        }
    }
}
?>