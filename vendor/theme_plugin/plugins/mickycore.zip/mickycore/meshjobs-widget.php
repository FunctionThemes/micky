<?php
/*============= start meshjobs Logo and Description Widget ===============*/
class meshjobs_footer_logo_Widget extends WP_Widget {
	function __construct() {
		parent::__construct(
			'meshjobs_footer_logo_Widget',
			esc_html__('meshjobs Logo and Description Widget', 'meshjobs'), 
			array( 'description' => esc_html__( 'Logo and Description Widget', 'meshjobs' ),)
		);
	}
	public function widget( $args, $instance ) {
		if( isset($instance['meshjobs_imgurl_option'])|| 
		    isset($instance['meshjobs_imgurl'])|| 
			isset($instance['meshjobs_description_option'])||	
            isset($instance['meshjobs_description'])
		)
		{
			$meshjobs_img_option = $instance['meshjobs_imgurl_option'];
			$meshjobs_img = $instance['meshjobs_imgurl'];
			$meshjobs_description_option = $instance['meshjobs_description_option'];
			$meshjobs_description = $instance['meshjobs_description'];
		}
		else {
			$meshjobs_img_option = '';
			$meshjobs_img = '';
			$meshjobs_description_option = '';
			$meshjobs_description = '';
		}
		echo $args['before_widget'];
			if($meshjobs_img_option=='on') {
				if(!empty($meshjobs_img)){ 
				$meshjobs_thumb_w = '171';
                $meshjobs_thumb_h = '50';
                $meshjobs_image = meshjobs_resize($meshjobs_img, $meshjobs_thumb_w, $meshjobs_thumb_h, true);
				    echo '<a href="'.esc_url( home_url( '/' )).'"><img src="'.esc_url($meshjobs_image).'" class="img-responsive" alt=""/></a>';
			    }
			} 
			?>
			<?php if($meshjobs_description_option=='on') { ?>
            <p><?php if(isset($meshjobs_description)) echo esc_html($meshjobs_description);?></p>
            <?php } ?>
			
			<?php
		echo $args['after_widget']; 
	}
	public function form( $instance ) {
		if( isset($instance['meshjobs_imgurl_option'])||
		isset($instance['meshjobs_imgurl'])||
		isset($instance['meshjobs_description_option'])||
		isset($instance['meshjobs_description'])
		)
		{
			$meshjobs_img_option = $instance['meshjobs_imgurl_option'];
			$meshjobs_img = $instance['meshjobs_imgurl'];
			$meshjobs_description_option = $instance['meshjobs_description_option'];
			$meshjobs_description = $instance['meshjobs_description'];
		}
		else {
			$meshjobs_img_option = '';
			$meshjobs_img = '';
			$meshjobs_description_option = '';
			$meshjobs_description = '';
		}
		?>
	    <p>
		<label for="<?php echo $this->get_field_id( 'meshjobs_imgurl_option' ); ?>"><?php echo esc_html__('Upload Image:','meshjobs'); ?></label>
		<select name="<?php echo $this->get_field_name( 'meshjobs_imgurl_option' ); ?>">
		<option value="<?php echo 'on'; ?>"<?php if($meshjobs_img_option=='on') echo 'selected'; ?>><?php echo 'ON'; ?></option>
		<option value="<?php echo 'off'; ?>" <?php if($meshjobs_img_option=='off') echo 'selected'; ?>><?php echo 'OFF'; ?></option>
		</select><br/><br/>
		<input class="widefat" id="<?php echo $this->get_field_id( 'meshjobs_imgurl' ); ?>" name="<?php echo $this->get_field_name( 'meshjobs_imgurl' ); ?>" type="text" value="<?php if(isset($meshjobs_img)) echo esc_url($meshjobs_img); ?>" >
		<input type="button" class="meshjobs_upload_image_button button button-primary" value="upload">
		</p>
		<p>
		<label for="<?php echo $this->get_field_id( 'meshjobs_description_option' ); ?>"><?php echo esc_html__('Description:','meshjobs'); ?></label>
		<select name="<?php echo $this->get_field_name( 'meshjobs_description_option' ); ?>">
		<option value="<?php echo 'on'; ?>" <?php if($meshjobs_description_option=='on') echo 'selected'; ?>><?php echo 'ON'; ?></option>
		<option value="<?php echo 'off'; ?>" <?php if($meshjobs_description_option=='off') echo 'selected'; ?>><?php echo 'OFF'; ?></option>
		</select><br/><br/>
		 <textarea class="widefat" rows="8" cols="10" id="<?php echo $this->get_field_id('meshjobs_description'); ?>" name="<?php echo $this->get_field_name('meshjobs_description'); ?>"><?php if (isset($meshjobs_description)) echo esc_html($meshjobs_description); ?></textarea>
		</p> 
		
	    <?php  
	}
	public function update( $new_instance, $old_instance ) {
		$instance = array();
		$instance['meshjobs_imgurl_option'] = (!empty($new_instance['meshjobs_imgurl_option']))?strip_tags($new_instance['meshjobs_imgurl_option']):'';
		$instance['meshjobs_imgurl'] = (!empty($new_instance['meshjobs_imgurl']))?strip_tags($new_instance['meshjobs_imgurl']):'';
		$instance['meshjobs_description_option'] = (!empty($new_instance['meshjobs_description_option']))?strip_tags($new_instance['meshjobs_description_option']):'';
		$instance['meshjobs_description'] = (!empty($new_instance['meshjobs_description']))?strip_tags($new_instance['meshjobs_description']):'';
		
		return $instance;
	}
}
function meshjobs_register_footer_logo() {
    register_widget( 'meshjobs_footer_logo_Widget' );
}
add_action( 'widgets_init', 'meshjobs_register_footer_logo' );
/*============= close meshjobs Logo and Description Widget ===============*/
/*============= start meshjobs social Widget ===============*/
class meshjobs_footer_social_Widget extends WP_Widget {
	function __construct() {
		parent::__construct(
			'meshjobs_footer_social_Widget',
			esc_html__('meshjobs Social Widget', 'meshjobs'), 
			array( 'description' => esc_html__( 'Social Widget', 'meshjobs' ),)
		);
	}
	public function widget( $args, $instance ) {
		if( isset($instance['meshjobs_contact_title'])|| 
		    isset($instance['meshjobs_social_option'])||	
            isset($instance['meshjobs_social_facebook'])||
            isset($instance['meshjobs_social_twitter'])||
            isset($instance['meshjobs_social_googlepluse'])||
            isset($instance['meshjobs_social_skype'])||
            isset($instance['meshjobs_social_linkedin'])||
            isset($instance['meshjobs_social_dribbble'])||
            isset($instance['meshjobs_social_youtube'])||
            isset($instance['meshjobs_social_flickr'])||
            isset($instance['meshjobs_social_pinterest'])
		)
		{
			$meshjobs_contact_title = $instance['meshjobs_contact_title'];
			$meshjobs_social_option = $instance['meshjobs_social_option'];
			$meshjobs_social_facebook = $instance['meshjobs_social_facebook'];
			$meshjobs_social_twitter = $instance['meshjobs_social_twitter'];
			$meshjobs_social_googlepluse = $instance['meshjobs_social_googlepluse'];
			$meshjobs_social_skype = $instance['meshjobs_social_skype'];
			$meshjobs_social_linkedin = $instance['meshjobs_social_linkedin'];
			$meshjobs_social_dribbble = $instance['meshjobs_social_dribbble'];
			$meshjobs_social_youtube = $instance['meshjobs_social_youtube'];
			$meshjobs_social_flickr = $instance['meshjobs_social_flickr'];
			$meshjobs_social_pinterest = $instance['meshjobs_social_pinterest'];
		}
		else {
			$meshjobs_contact_title = '';
			$meshjobs_social_option = '';
			$meshjobs_social_facebook = '';
			$meshjobs_social_twitter = '';
			$meshjobs_social_googlepluse = '';
			$meshjobs_social_skype = '';
			$meshjobs_social_linkedin = '';
			$meshjobs_social_dribbble = '';
			$meshjobs_social_youtube = '';
			$meshjobs_social_flickr = '';
			$meshjobs_social_pinterest = '';
		}
		echo $args['before_widget']; 
		if(!empty($meshjobs_contact_title)){
		echo $args['before_title'] . esc_html($meshjobs_contact_title) . $args['after_title'];
		}
		?>
			<div class="mj_sociallink">
			<?php if($meshjobs_social_option=='on') { 
			global $meshjobs_data;
			$meshjobs_facebook = $meshjobs_twitter = $meshjobs_googlepluse = $meshjobs_skype  = $meshjobs_linkedin = $meshjobs_dribbble = $meshjobs_youtube = $meshjobs_flickr = $meshjobs_pinterest = '';
			if(isset($meshjobs_data['meshjobs_facebookurl']))
			  $meshjobs_facebook = $meshjobs_data['meshjobs_facebookurl'];
		    if(isset($meshjobs_data['meshjobs_twitterurl']))
			  $meshjobs_twitter = $meshjobs_data['meshjobs_twitterurl'];
		    if(isset($meshjobs_data['meshjobs_gpurl']))
			  $meshjobs_googlepluse = $meshjobs_data['meshjobs_gpurl'];
		    if(isset($meshjobs_data['meshjobs_skypeurl']))
			  $meshjobs_skype = $meshjobs_data['meshjobs_skypeurl'];
			if(isset($meshjobs_data['meshjobs_linkedinurl']))
			  $meshjobs_linkedin = $meshjobs_data['meshjobs_linkedinurl'];
			if(isset($meshjobs_data['meshjobs_dribbbleurl']))
			  $meshjobs_dribbble = $meshjobs_data['meshjobs_dribbbleurl'];
			if(isset($meshjobs_data['meshjobs_youtubeurl']))
			  $meshjobs_youtube = $meshjobs_data['meshjobs_youtubeurl'];
			if(isset($meshjobs_data['meshjobs_flickrurl']))
			  $meshjobs_flickr = $meshjobs_data['meshjobs_flickrurl'];
			if(isset($meshjobs_data['meshjobs_pinteresturl']))
			  $meshjobs_pinterest = $meshjobs_data['meshjobs_pinteresturl'];
			?>
				<ul>
					<?php if($meshjobs_social_facebook=='on') { ?>
					<li><a href="<?php echo esc_url($meshjobs_facebook); ?>" data-toggle="tooltip" data-placement="bottom" title="facebook" target="_blank"><i class="fa fa-facebook"></i></a></li>
					<?php }
				    if($meshjobs_social_twitter=='on') { ?>
					<li><a href="<?php echo esc_url($meshjobs_twitter); ?>" data-toggle="tooltip" data-placement="bottom" title="twitter" target="_blank"><i class="fa fa-twitter"></i></a></li>
					<?php }
				    if($meshjobs_social_googlepluse=='on') { ?>
					<li><a href="<?php echo esc_url($meshjobs_googlepluse); ?>" data-toggle="tooltip" data-placement="bottom" title="google" target="_blank"><i class="fa fa-google-plus"></i></a></li>
					<?php }
				    if($meshjobs_social_skype=='on') { ?>
					<li><a href="<?php echo esc_url($meshjobs_skype); ?>" data-toggle="tooltip" data-placement="bottom" title="skype" target="_blank"><i class="fa fa-skype"></i></a></li>
					<?php }
				    if($meshjobs_social_linkedin=='on') { ?>
					<li><a href="<?php echo esc_url($meshjobs_linkedin); ?>" data-toggle="tooltip" data-placement="bottom" title="linkedin" target="_blank"><i class="fa fa-linkedin"></i></a></li>
					<?php }
				    if($meshjobs_social_dribbble=='on') { ?>
					<li><a href="<?php echo esc_url($meshjobs_dribbble); ?>" data-toggle="tooltip" data-placement="bottom" title="dribbble" target="_blank"><i class="fa fa-dribbble"></i></a></li>
					<?php }
				    if($meshjobs_social_youtube=='on') { ?>
					<li><a href="<?php echo esc_url($meshjobs_youtube); ?>" data-toggle="tooltip" data-placement="bottom" title="youtube" target="_blank"><i class="fa fa-youtube-square"></i></a></li>
					<?php }
				    if($meshjobs_social_flickr=='on') { ?>
					<li><a href="<?php echo esc_url($meshjobs_flickr); ?>" data-toggle="tooltip" data-placement="bottom" title="flickr" target="_blank"><i class="fa fa-flickr"></i></a></li>
					<?php }
				    if($meshjobs_social_pinterest=='on') { ?>
					<li><a href="<?php echo esc_url($meshjobs_pinterest); ?>" data-toggle="tooltip" data-placement="bottom" title="pinterest" target="_blank"><i class="fa fa-pinterest-square"></i></a></li>
					<?php } ?>
				</ul>
            <?php } ?>
			</div>
			<?php
		echo $args['after_widget']; 
	}
	public function form( $instance ) {
		if( isset($instance['meshjobs_contact_title'])|| 
		isset($instance['meshjobs_social_option'])||	
		isset($instance['meshjobs_social_facebook'])||
		isset($instance['meshjobs_social_twitter'])||
		isset($instance['meshjobs_social_googlepluse'])||
		isset($instance['meshjobs_social_skype'])||
		isset($instance['meshjobs_social_linkedin'])||
		isset($instance['meshjobs_social_dribbble'])||
		isset($instance['meshjobs_social_youtube'])||
		isset($instance['meshjobs_social_flickr'])||
		isset($instance['meshjobs_social_pinterest'])
		)
		{
			$meshjobs_contact_title = $instance['meshjobs_contact_title'];
			$meshjobs_social_option = $instance['meshjobs_social_option'];
			$meshjobs_social_facebook = $instance['meshjobs_social_facebook'];
			$meshjobs_social_twitter = $instance['meshjobs_social_twitter'];
			$meshjobs_social_googlepluse = $instance['meshjobs_social_googlepluse'];
			$meshjobs_social_skype = $instance['meshjobs_social_skype'];
			$meshjobs_social_linkedin = $instance['meshjobs_social_linkedin'];
			$meshjobs_social_dribbble = $instance['meshjobs_social_dribbble'];
			$meshjobs_social_youtube = $instance['meshjobs_social_youtube'];
			$meshjobs_social_flickr = $instance['meshjobs_social_flickr'];
			$meshjobs_social_pinterest = $instance['meshjobs_social_pinterest'];
		}
		else {
			$meshjobs_contact_title = '';
			$meshjobs_social_option = '';
			$meshjobs_social_facebook = '';
			$meshjobs_social_twitter = '';
			$meshjobs_social_googlepluse = '';
			$meshjobs_social_skype = '';
			$meshjobs_social_linkedin = '';
			$meshjobs_social_dribbble = '';
			$meshjobs_social_youtube = '';
			$meshjobs_social_flickr = '';
			$meshjobs_social_pinterest = '';
		}
		?>
	    <p>
		<label for="<?php echo $this->get_field_id( 'meshjobs_contact_title' ); ?>"><?php echo esc_html__('Title:','meshjobs'); ?></label>
		<input class="widefat" id="<?php echo $this->get_field_id( 'meshjobs_contact_title' ); ?>" name="<?php echo $this->get_field_name( 'meshjobs_contact_title' ); ?>" type="text" value="<?php if(isset($meshjobs_contact_title)) echo esc_attr($meshjobs_contact_title); ?>" >
		</p> 
		<p>
		<label for="<?php echo $this->get_field_id( 'meshjobs_social_option' ); ?>"><?php echo esc_html__('Social Media :','meshjobs'); ?></label>
		<select name="<?php echo $this->get_field_name( 'meshjobs_social_option' ); ?>">
		<option value="<?php echo 'on'; ?>"<?php if($meshjobs_social_option=='on') echo 'selected'; ?>><?php echo 'ON'; ?></option>
		<option value="<?php echo 'off'; ?>" <?php if($meshjobs_social_option=='off') echo 'selected'; ?>><?php echo 'OFF'; ?></option>
		</select><br/>
		 <input class="widefat" id="<?php echo $this->get_field_id( 'meshjobs_social_facebook' ); ?>" name="<?php echo $this->get_field_name( 'meshjobs_social_facebook' ); ?>" type="checkbox" value="<?php echo 'on'; ?>" <?php if($meshjobs_social_facebook=='on') echo "checked"; ?>>
		  <?php echo esc_html__('Show Facebook','meshjobs'); ?>
		 <br/><br/>
		 <input class="widefat" id="<?php echo $this->get_field_id( 'meshjobs_social_twitter' ); ?>" name="<?php echo $this->get_field_name( 'meshjobs_social_twitter' ); ?>" type="checkbox" value="<?php echo 'on'; ?>" <?php if($meshjobs_social_twitter=='on') echo "checked"; ?> >
		  <?php echo esc_html__('Show Twitter','meshjobs'); ?>
		 <br/><br/>
		 <input class="widefat" id="<?php echo $this->get_field_id( 'meshjobs_social_googlepluse' ); ?>" name="<?php echo $this->get_field_name( 'meshjobs_social_googlepluse' ); ?>" type="checkbox" value="<?php echo 'on'; ?>" <?php if($meshjobs_social_googlepluse=='on') echo "checked"; ?> >
		  <?php echo esc_html__('Show Google pluse','meshjobs'); ?>
		 <br/><br/>
		 <input class="widefat" id="<?php echo $this->get_field_id( 'meshjobs_social_skype' ); ?>" name="<?php echo $this->get_field_name( 'meshjobs_social_skype' ); ?>" type="checkbox" value="<?php echo 'on'; ?>" <?php if($meshjobs_social_skype=='on') echo "checked"; ?> >
		  <?php echo esc_html__('Show Skype','meshjobs'); ?>
		 <br/><br/>
		 <input class="widefat" id="<?php echo $this->get_field_id( 'meshjobs_social_linkedin' ); ?>" name="<?php echo $this->get_field_name( 'meshjobs_social_linkedin' ); ?>" type="checkbox" value="<?php echo 'on'; ?>" <?php if($meshjobs_social_linkedin=='on') echo "checked"; ?> >
		 <?php echo esc_html__('Show Linkedin','meshjobs'); ?>
		 <br/><br/>
		 <input class="widefat" id="<?php echo $this->get_field_id( 'meshjobs_social_dribbble' ); ?>" name="<?php echo $this->get_field_name( 'meshjobs_social_dribbble' ); ?>" type="checkbox" value="<?php echo 'on'; ?>" <?php if($meshjobs_social_dribbble=='on') echo "checked"; ?> >
		 <?php echo esc_html__('Show Dribbble','meshjobs'); ?>
		 <br/><br/>
		 <input class="widefat" id="<?php echo $this->get_field_id( 'meshjobs_social_youtube' ); ?>" name="<?php echo $this->get_field_name( 'meshjobs_social_youtube' ); ?>" type="checkbox" value="<?php echo 'on'; ?>" <?php if($meshjobs_social_youtube=='on') echo "checked"; ?> >
		 <?php echo esc_html__('Show Youtube','meshjobs'); ?>
		 <br/><br/>
		 <input class="widefat" id="<?php echo $this->get_field_id( 'meshjobs_social_flickr' ); ?>" name="<?php echo $this->get_field_name( 'meshjobs_social_flickr' ); ?>" type="checkbox" value="<?php echo 'on'; ?>" <?php if($meshjobs_social_flickr=='on') echo "checked"; ?> >
		 <?php echo esc_html__('Show Flickr','meshjobs'); ?>
		 <br/><br/>
		 <input class="widefat" id="<?php echo $this->get_field_id( 'meshjobs_social_pinterest' ); ?>" name="<?php echo $this->get_field_name( 'meshjobs_social_pinterest' ); ?>" type="checkbox" value="<?php echo 'on'; ?>" <?php if($meshjobs_social_pinterest=='on') echo "checked"; ?> >
		 <?php echo esc_html__('Show Pinterest','meshjobs'); ?>
		</p>
	    <?php  
	}
	public function update( $new_instance, $old_instance ) {
		$instance = array();
		$instance['meshjobs_contact_title'] = (!empty($new_instance['meshjobs_contact_title']))?strip_tags($new_instance['meshjobs_contact_title']):'';
		$instance['meshjobs_social_option'] = (!empty($new_instance['meshjobs_social_option']))?strip_tags($new_instance['meshjobs_social_option']):'';
		$instance['meshjobs_social_facebook'] = (!empty($new_instance['meshjobs_social_facebook']))?strip_tags($new_instance['meshjobs_social_facebook']):'';
		$instance['meshjobs_social_twitter'] = (!empty($new_instance['meshjobs_social_twitter']))?strip_tags($new_instance['meshjobs_social_twitter']):'';
		$instance['meshjobs_social_googlepluse'] = (!empty($new_instance['meshjobs_social_googlepluse']))?strip_tags($new_instance['meshjobs_social_googlepluse']):'';
		$instance['meshjobs_social_skype'] = (!empty($new_instance['meshjobs_social_skype']))?strip_tags($new_instance['meshjobs_social_skype']):'';
		$instance['meshjobs_social_linkedin'] = (!empty($new_instance['meshjobs_social_linkedin']))?strip_tags($new_instance['meshjobs_social_linkedin']):'';
		$instance['meshjobs_social_dribbble'] = (!empty($new_instance['meshjobs_social_dribbble']))?strip_tags($new_instance['meshjobs_social_dribbble']):'';
		$instance['meshjobs_social_youtube'] = (!empty($new_instance['meshjobs_social_youtube']))?strip_tags($new_instance['meshjobs_social_youtube']):'';
		$instance['meshjobs_social_flickr'] = (!empty($new_instance['meshjobs_social_flickr']))?strip_tags($new_instance['meshjobs_social_flickr']):'';
		$instance['meshjobs_social_pinterest'] = (!empty($new_instance['meshjobs_social_pinterest']))?strip_tags($new_instance['meshjobs_social_pinterest']):'';
		
		return $instance;
	}
}
function meshjobs_register_footer_social() {
    register_widget( 'meshjobs_footer_social_Widget' );
}
add_action( 'widgets_init', 'meshjobs_register_footer_social' );
/*============= close meshjobs social Widget ===============*/
/*============= start meshjobs newsletter Widget ===============*/
class meshjobs_News_latter extends WP_Widget {
	function __construct() {
		$widget_ops = array('classname' => 'meshjobs_News_latter', 'description' => __('mailchimp newsletter.'));
		$control_ops = array('width' => 400, 'height' => 350);
		parent::__construct('meshjobs_news_latter', __('Meshjobs Newsletter'), $widget_ops, $control_ops);
	} 
	public function widget( $args, $instance ) {
		$title = $description = $key = $listid = $placeholder = '';
		if ( isset( $instance[ 'title' ] )  || isset( $instance[ 'key' ] )  || isset($instance[ 'listid' ]) ||  isset($instance[ 'placeholder' ]) ) {
			$title = $instance[ 'title' ];
			$key = $instance[ 'key' ];
			$listid = $instance[ 'listid' ];
			$placeholder = $instance[ 'placeholder' ];
		}
		echo $args['before_widget'];
		if(!empty($title)){
			echo $args['before_title'] . esc_attr($title) . $args['after_title'];	
		}
		if(!empty($key)){
			echo '<form class="form-inline mj_newsletter" id="mailchimp_subscribe">';
			echo '<div class="form-group"><input type="hidden" value="'.esc_attr($key).'" name="mailchimp_api_key" id="mailchimp_api_key">
			<input type="hidden" value="'.esc_attr($listid).'" name="mailchimp_list_id" id="mailchimp_list_id">';
			echo '<input type="text" class="form-control" value="" placeholder="'.esc_attr($placeholder).'"  onfocus="if(this.value==\'enter email address\')this.value=\'\'" onblur="if(this.value==\'\')this.value=\'enter email address\'" name="mailchimp_email"  id="mailchimp_email"/>';
			echo '<button class="mj_newsletterbtn" type="submit"><img src="'.PLUGIN_PATH.'images/icon-mail.png" alt=""></button>';
			echo '</div></form>';
			echo '<div class="mailchimp_message"></div>';
		}
		echo $args['after_widget'];
	}
	public function form( $instance ) {
		$title = $key = $listid = $placeholder = '';
		if ( isset( $instance[ 'title' ] )  || isset( $instance[ 'key' ] )  || isset($instance[ 'listid' ]) ||  isset($instance[ 'placeholder' ]) ) {
			$title = $instance[ 'title' ];
			$key = $instance[ 'key' ];
			$listid = $instance[ 'listid' ];
			$placeholder = $instance[ 'placeholder' ];
		}
		?>
		<p>
		<label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e('Title:','meshjobs'); ?></label> 
		<input class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>">
		</p>
		<p>
		<label for="<?php echo $this->get_field_id( 'key' ); ?>"><?php _e('MailChimp Api Key:','meshjobs'); ?></label> 
		<input class="widefat" id="<?php echo $this->get_field_id( 'key' ); ?>" name="<?php echo $this->get_field_name( 'key' ); ?>" type="text" value="<?php echo esc_attr( $key ); ?>">
		</p>
		<p>
		<label for="<?php echo $this->get_field_id( 'listid' ); ?>"><?php _e('MailChimp List Id:','meshjobs'); ?></label> 
		<input class="widefat" id="<?php echo $this->get_field_id( 'listid' ); ?>" name="<?php echo $this->get_field_name( 'listid' ); ?>" type="text" value="<?php echo esc_attr( $listid ); ?>">
		</p>
		<p>
		<label for="<?php echo $this->get_field_id( 'placeholder' ); ?>"><?php _e('Placeholder Text:','meshjobs'); ?></label> 
		<input class="widefat" id="<?php echo $this->get_field_id( 'placeholder' ); ?>" name="<?php echo $this->get_field_name( 'placeholder' ); ?>" type="text" value="<?php echo esc_attr( $placeholder ); ?>">
		</p>
		  <?php 
	}
	public function update( $new_instance, $old_instance ) {
		$instance = array();
		$instance['title'] = ( ! empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : '';
		$instance['key'] = ( ! empty( $new_instance['key'] ) ) ? strip_tags( $new_instance['key'] ) : '';
		$instance['listid'] = ( ! empty( $new_instance['listid'] ) ) ? strip_tags( $new_instance['listid'] ) : '';
		$instance['placeholder'] = ( ! empty( $new_instance['placeholder'] ) ) ? strip_tags( $new_instance['placeholder'] ) : '';
		return $instance;
	}
}
function meshjobs_register_news_latter_widget() {
    register_widget( 'meshjobs_News_latter' );
}
add_action( 'widgets_init', 'meshjobs_register_news_latter_widget' );
/*********========== Mailchimp Footer Widget Subscription =========**************/
add_action('wp_ajax_meshjobs_mailchimp_footer_subcription', 'meshjobs_mailchimp_footer_subcription');
add_action('wp_ajax_nopriv_meshjobs_mailchimp_footer_subcription', 'meshjobs_mailchimp_footer_subcription');
if(!function_exists('meshjobs_mailchimp_footer_subcription')){  
	function meshjobs_mailchimp_footer_subcription(){
		$api_key = $_POST['apikey'];
		$list_id = $_POST['listid'];   
		plugins_url('meshjobs-widget.php','meshjobs'); 
		$Mailchimp = new Mailchimp( $api_key );
		$Mailchimp_Lists = new Mailchimp_Lists( $Mailchimp );
		$subscriber = $Mailchimp_Lists->subscribe( $list_id, array( 'email' => htmlentities($_POST['subc_email']) ) );
		if ( ! empty( $subscriber['leid'] ) ) {
		   echo esc_html__('success','meshjobs');
		}else{
			echo esc_html__('fail','meshjobs'); 
		}
		die();
	}
} 
/*============= close meshjobs newsletter Widget ===============*/
/*============= start flickr Widget ===============*/
class meshjobs_flickr_Widget extends WP_Widget {
	function __construct() {
		parent::__construct(
			'flickr',
			esc_html__('meshjobs Flickr Photos Widget', 'meshjobs'), 
			array( 'description' => esc_html__( 'Show Your Favorite Flickr Photos!', 'meshjobs' ),)
		);
	}
	public function widget( $args, $instance ) {
		if( isset($instance['meshjobs_flickr_title'])|| 
		    isset($instance['meshjobs_flickr_user'])|| 
			isset($instance['meshjobs_flickr_apikey'])||	
            isset($instance['meshjobs_flickr_number'])
		)
		{
			$meshjobs_flickr_title = $instance['meshjobs_flickr_title'];
			$meshjobs_flickr_user = $instance['meshjobs_flickr_user'];
			$meshjobs_flickr_apikey = $instance['meshjobs_flickr_apikey'];
			$meshjobs_flickr_number = $instance['meshjobs_flickr_number'];
		}
		else {
			$meshjobs_flickr_title = '';
			$meshjobs_flickr_user = '';
			$meshjobs_flickr_apikey = '';
			$meshjobs_flickr_number = '';
		}
		require_once('phpFlickr/phpFlickr.php'); 
        $meshjobs_flickr_key = new phpFlickr($meshjobs_flickr_apikey);
		echo $args['before_widget'];
		if(!empty($meshjobs_flickr_title)){
			echo $args['before_title'] . esc_attr($meshjobs_flickr_title) . $args['after_title'];	
		}
		if (!empty($meshjobs_flickr_user) && ($meshjobs_flickr_apikey)) {
			
		$person = $meshjobs_flickr_key->people_findByUsername($meshjobs_flickr_user);   
		$photos_url = $meshjobs_flickr_key->urls_getUserPhotos($person['id']); 
		$photos = $meshjobs_flickr_key->people_getPublicPhotos($person['id'], NULL, NULL, $meshjobs_flickr_number);
		 echo '<ul>';
		 $purl = $palt = $psrc = '';
		foreach ((array)$photos['photos']['photo'] as $photo) {
			echo '<li>';
			$purl = $photos_url.''.$photo['id'];
			$palt = $photo['title'];
			$psrc = $meshjobs_flickr_key->buildPhotoURL($photo, 'Small');
			echo '<a href="'.esc_url($purl).'">';			
			echo '<img alt="'.esc_attr($palt).'" src="'.esc_url($psrc).'">';
			echo '</a>';
			echo '</li>'; 
		}
		echo '</ul>';
		}
		echo $args['after_widget']; 
	}
	public function form( $instance ) {
		if( isset($instance['meshjobs_flickr_title'])||
		isset($instance['meshjobs_flickr_user'])||
		isset($instance['meshjobs_flickr_apikey'])||
		isset($instance['meshjobs_flickr_number'])
		)
		{
			$meshjobs_flickr_title = $instance['meshjobs_flickr_title'];
			$meshjobs_flickr_user = $instance['meshjobs_flickr_user'];
			$meshjobs_flickr_apikey = $instance['meshjobs_flickr_apikey'];
			$meshjobs_flickr_number = $instance['meshjobs_flickr_number'];
		}
		else {
			$meshjobs_flickr_title = '';
			$meshjobs_flickr_user = '';
			$meshjobs_flickr_apikey = '';
			$meshjobs_flickr_number = '';
		}
		?> 
		<p>
		<label for="<?php echo $this->get_field_id( 'meshjobs_flickr_title' ); ?>"><?php echo esc_html__('Title:','meshjobs'); ?></label> 
		<input class="widefat" id="<?php echo $this->get_field_id( 'meshjobs_flickr_title' ); ?>" name="<?php echo $this->get_field_name( 'meshjobs_flickr_title' ); ?>" type="text" value="<?php echo esc_attr( $meshjobs_flickr_title ); ?>">
		</p>
		<p>
		<label for="<?php echo $this->get_field_id( 'meshjobs_flickr_user' ); ?>"><?php echo esc_html__('Flickr Username:','meshjobs'); ?></label> 
		<input class="widefat" id="<?php echo $this->get_field_id( 'meshjobs_flickr_user' ); ?>" name="<?php echo $this->get_field_name( 'meshjobs_flickr_user' ); ?>" type="text" value="<?php echo esc_attr( $meshjobs_flickr_user ); ?>">
		</p>
		<p>
		<label for="<?php echo $this->get_field_id( 'meshjobs_flickr_apikey' ); ?>"><?php echo esc_html__('Flickr Apikey:','meshjobs'); ?></label> 
		<input class="widefat" id="<?php echo $this->get_field_id( 'meshjobs_flickr_apikey' ); ?>" name="<?php echo $this->get_field_name( 'meshjobs_flickr_apikey' ); ?>" type="text" value="<?php echo esc_attr( $meshjobs_flickr_apikey ); ?>">
		</p>
		<p>
		<label for="<?php echo $this->get_field_id( 'meshjobs_flickr_number' ); ?>"><?php echo esc_html__('Number Of Photos:','meshjobs'); ?></label> 
		<input class="widefat" id="<?php echo $this->get_field_id( 'meshjobs_flickr_number' ); ?>" name="<?php echo $this->get_field_name( 'meshjobs_flickr_number' ); ?>" type="text" value="<?php echo esc_attr( $meshjobs_flickr_number ); ?>">
		</p>		
	    <?php  
	}
	public function update( $new_instance, $old_instance ) {
		$instance = array();
		$instance['meshjobs_flickr_title'] = (!empty($new_instance['meshjobs_flickr_title']))?strip_tags($new_instance['meshjobs_flickr_title']):'';
		$instance['meshjobs_flickr_user'] = (!empty($new_instance['meshjobs_flickr_user']))?strip_tags($new_instance['meshjobs_flickr_user']):'';
		$instance['meshjobs_flickr_apikey'] = (!empty($new_instance['meshjobs_flickr_apikey']))?strip_tags($new_instance['meshjobs_flickr_apikey']):'';
		$instance['meshjobs_flickr_number'] = (!empty($new_instance['meshjobs_flickr_number']))?strip_tags($new_instance['meshjobs_flickr_number']):'';
		
		return $instance;
	}
}
function meshjobs_register_footer_flickr() {
    register_widget( 'meshjobs_flickr_Widget' );
}
add_action( 'widgets_init', 'meshjobs_register_footer_flickr' );
/*============= close flickr Widget ===============*/
?>