<?php
//*********************** shortcode ****************************//
add_action( 'vc_before_init', 'meshjobs_WITHVS' );
function meshjobs_WITHVS() {
	vc_map( array(
        "name" => __("Meshjobs Heading",'meshjobs'),
        "base" => "meshjobs_heading",
        "class" => "", 
        "category" => __('Content','meshjobs'),
        "params" => array(
		    array(
            "type" => "textfield",
            "holder" => "div",
            "class" => "",
            "heading" => __("Title",'meshjobs'),
            "param_name" => "heading_title",
            "value" => __("",'meshjobs'),
            "description" => __("Title text Here.",'meshjobs'),
            ),
		    array(
            "type" => "textfield",
            "holder" => "div",
            "class" => "",
            "heading" => __("Subtitle",'meshjobs'),
            "param_name" => "heading_subtitle",
            "value" => __("",'meshjobs'),
            "description" => __("Subtitle text Here.",'meshjobs')
            ),
        )
    ) );
	vc_map( array(
        "name" => __("Meshjobs Section Space",'meshjobs'),
        "base" => "meshjobs_padding",
        "class" => "", 
        "category" => __('Content','meshjobs'),
        "params" => array(
		    array(
            "type" => "textfield",
            "holder" => "div",
            "class" => "",
            "heading" => __("Insert Section Space",'meshjobs'),
            "param_name" => "heading_title",
            "value" => __("50px",'meshjobs'),
            "description" => __("Insert Space in px",'meshjobs'),
            ),
        )
    ) );
	vc_map( array(
        "name" => __("Meshjobs Banner",'meshjobs'),
        "base" => "meshjobs_banner",
        "class" => "", 
        "category" => __('Content','meshjobs'),
        "params" => array(
		    array(
            "type" => "attach_image",
            "holder" => "div",
            "class" => "",
            "heading" => __("Upload Banner Image",'meshjobs'),
            "param_name" => "banner_img", 
            "value" => __("",'meshjobs'),
            "description" => __("Upload Image Here.",'meshjobs')
            ),
			array(
            "type" => "textfield",
            "holder" => "div",
            "class" => "",
            "heading" => __("Title",'meshjobs'),
            "param_name" => "banner_title",
            "value" => __("",'meshjobs'),
            "description" => __("Title text Here.",'meshjobs'),
            ),
		    array(
            "type" => "textfield",
            "holder" => "div",
            "class" => "",
            "heading" => __("Subtitle",'meshjobs'),
            "param_name" => "banner_subtitle",
            "value" => __("",'meshjobs'),
            "description" => __("Subtitle text Here.",'meshjobs')
            ),
        )
    ) );
	vc_map( array(
        "name" => __("Meshjobs Recent Jobs",'meshjobs'),
        "base" => "meshjobs_recentjob", 
        "class" => "", 
        "category" => __('Content','meshjobs'),
        "params" => array(
		    array(
            "type" => "textfield",
            "holder" => "div",
            "class" => "",
            "heading" => __("Number Of Post",'meshjobs'),
            "param_name" => "recentjob_no",
            "value" => __("8",'meshjobs'),
            "description" => __("Insert integer Values Here.",'meshjobs'),
            ),
		    array(
            "type" => "alert-box",
            "holder" => "div",
            "class" => "",
			"heading" => __("Note:-",'meshjobs'),
            "param_name" => "recentjob_note",
            "value" => __("",'meshjobs'),
            "description" => __("Show your all Recent Jobs.",'meshjobs'),
            ),
        )
    ) );
	vc_map( array(
        "name" => __("Meshjobs Gallery",'meshjobs'),
        "base" => "meshjobs_gallery", 
        "class" => "", 
        "category" => __('Content','meshjobs'),
        "params" => array(
		    array(
            "type" => "alert-box",
            "holder" => "div",
            "class" => "",
			"heading" => __("Note:-",'meshjobs'),
            "param_name" => "gallery_note",
            "value" => __("",'meshjobs'),
            "description" => __("Set your gallery section with gallery custom post type.",'meshjobs'),
            ),
        )
    ) );
	vc_map( array(
        "name" => __("Meshjobs Team",'meshjobs'),
        "base" => "meshjobs_team", 
        "class" => "", 
        "category" => __('Content','meshjobs'),
        "params" => array(
		    array(
            "type" => "alert-box",
            "holder" => "div",
            "class" => "",
			"heading" => __("Note:-",'meshjobs'),
            "param_name" => "team_note",
            "value" => __("",'meshjobs'),
            "description" => __("Set your team section with team custom post type.",'meshjobs'),
            ),
        )
    ) );
	vc_map( array(
        "name" => __("Meshjobs Work",'meshjobs'),
        "base" => "meshjobs_work", 
        "class" => "", 
        "category" => __('Content','meshjobs'),
        "params" => array(
		    array(
		    "type"        => "dropdown",
		    "heading"     => __("Choose Your Style Type",'meshjobs'),
		    "param_name"  => "work_pattern",
		    "admin_label" => true,
		    "value"=>array("Vertical Box"=>"1", "Horizontal Box"=>"2"),
		    "description" => __("Choose Style pattern.",'meshjobs')
            ), 
		    array(
            "type" => "textfield",
            "holder" => "div",
            "class" => "",
            "heading" => __("Work Title",'meshjobs'),
            "param_name" => "work_title",
            "value" => __("",'meshjobs'),
            "description" => __("Title text Here.",'meshjobs'),
            ),
			array(
            "type" => "attach_image",
            "holder" => "div",
            "class" => "",
            "heading" => __("Upload Image",'meshjobs'),
            "param_name" => "work_img", 
            "value" => __("",'meshjobs'),
            "description" => __("Upload Image Here.",'meshjobs')
            ),
			array(
            "type" => "textarea",
            "holder" => "div",
            "class" => "",
            "heading" => __("Description",'meshjobs'),
            "param_name" => "work_description",
            "value" => __("",'meshjobs'),
            "description" => __("Description text Here.",'meshjobs'),
            ),
			array(
            "type" => "vc_link",
            "holder" => "div",
            "class" => "",
            "heading" => __("Read More Button",'meshjobs'),
            "param_name" => "work_read_more",
            "value" => __("",'meshjobs'),
            "description" => __("Edit Read More Button Here.",'meshjobs')
         ),
        )
    ) );
	vc_map( array(
        "name" => __("Meshjobs Articals",'meshjobs'),
        "base" => "meshjobs_articals",
        "class" => "", 
        "category" => __('Content','meshjobs'),
        "params" => array(
		    array(
            "type" => "textfield",
            "holder" => "div",
            "class" => "",
            "heading" => __("Number Of Post",'meshjobs'),
            "param_name" => "articals_no",
            "value" => __("6",'meshjobs'),
            "description" => __("Insert integer Values Here.",'meshjobs'),
            ),
        )
    ) );
	vc_map( array(
		"name" => __("Meshjobs Testimonial", "meshjobs"),
		"base" => "testimonial_parent",
		"as_parent" => array('only' => 'testimonial_child'), // Use only|except attributes to limit child shortcodes (separate multiple values with comma)
		"content_element" => true,
		"show_settings_on_create" => false,
		"params" => array( 
			// add params same as with any other content element
			array(
			"type" => "attach_image",
			"holder" => "div",
			"class" => "",
			"heading" => __("Upload Background Image",'meshjobs'),
			"param_name" => "testimonial_bg_img", 
			"value" => __("",'meshjobs'),
			"description" => __("Upload BG Image Here.",'meshjobs')
			),
			array(
            "type" => "textarea",
            "holder" => "div",
            "class" => "",
            "heading" => __("Description",'meshjobs'),
            "param_name" => "testimonial_description",
            "value" => __("",'meshjobs'),
            "description" => __("Description text Here.",'meshjobs'),
            ),
		), 
		"js_view" => 'VcColumnView'
	) );
	//Your "container" content element should extend WPBakeryShortCodesContainer class to inherit all required functionality
	if ( class_exists( 'WPBakeryShortCodesContainer' ) && !class_exists( 'WPBakeryShortCode_testimonial_parent' ) ) {
		class WPBakeryShortCode_testimonial_parent extends WPBakeryShortCodesContainer {
		}
	}
	vc_map( array(
        "name" => __("Meshjobs Testimonial Content",'meshjobs'),
        "base" => "testimonial_child",
        "class" => "", 
        "category" => __('Content','meshjobs'),
		"as_child" => array('only' => 'testimonial_parent'),
        "params" => array(
		    array(
			"type" => "attach_image",
			"holder" => "div",
			"class" => "",
			"heading" => __("Upload Client Image",'meshjobs'),
			"param_name" => "testimonial_img", 
			"value" => __("",'meshjobs'),
			"description" => __("Upload Image Here.",'meshjobs')
			),
			array(
            "type" => "textarea",
            "holder" => "div",
            "class" => "",
            "heading" => __("Client Says",'meshjobs'),
            "param_name" => "testimonial_content",
            "value" => __("",'meshjobs'),
            "description" => __("Content text Here.",'meshjobs'),
            ),
			array(
            "type" => "textfield",
            "holder" => "div",
            "class" => "",
            "heading" => __("Client Name",'meshjobs'),
            "param_name" => "testimonial_name",
            "value" => __("",'meshjobs'),
            "description" => __("Client Name Here.",'meshjobs')
            ),
			array(
            "type" => "textfield",
            "holder" => "div",
            "class" => "",
            "heading" => __("Client Designation",'meshjobs'),
            "param_name" => "testimonial_designation",
            "value" => __("",'meshjobs'),
            "description" => __("Client Designation Here.",'meshjobs')
            ),
        ) 
    ) );
	vc_map( array(
		"name" => __("Meshjobs Price Table", "meshjobs"),
		"base" => "price_parent",
		"as_parent" => array('only' => 'price_child'), // Use only|except attributes to limit child shortcodes (separate multiple values with comma)
		"content_element" => true,
		"show_settings_on_create" => false,
		"params" => array( 
			// add params same as with any other content element
			array(
		    "type"        => "dropdown",
		    "heading"     => __("Choose Your Table Color"),
		    "param_name"  => "price_color",
		    "admin_label" => true,
		    "value"=>array("Green"=>"1", "Blue"=>"2", "Yellow"=>"3", "Orange"=>"4"),
		    "description" => __("")
            ), 
		    array(
            "type" => "textfield",
            "holder" => "div",
            "class" => "",
            "heading" => __("Price",'meshjobs'),
            "param_name" => "price_no",
            "value" => __("$50",'meshjobs'),
            "description" => __("Insert integer Values With Your Currency Sign Here.",'meshjobs'),
            ),
			array(
            "type" => "textfield",
            "holder" => "div",
            "class" => "",
            "heading" => __("Title",'meshjobs'),
            "param_name" => "price_title",
            "value" => __("free",'meshjobs'),
            "description" => __("",'meshjobs'),
            ),
			array(
            "type" => "textfield",
            "holder" => "div",
            "class" => "",
            "heading" => __("Subtitle",'meshjobs'),
            "param_name" => "price_subtitle",
            "value" => __("For 1 job listed for 30 days",'meshjobs'),
            "description" => __("",'meshjobs'),
            ),
			array(
            "type" => "vc_link",
            "holder" => "div",
            "class" => "",
            "heading" => __("Edit Button",'meshjobs'),
            "param_name" => "price_link",
            "value" => __("",'meshjobs'),
            "description" => __("Edit Button Here.",'meshjobs')
            ),
		), 
		"js_view" => 'VcColumnView'
	) );
	//Your "container" content element should extend WPBakeryShortCodesContainer class to inherit all required functionality
	if ( class_exists( 'WPBakeryShortCodesContainer' ) && !class_exists( 'WPBakeryShortCode_price_parent' )) {
		class WPBakeryShortCode_price_parent extends WPBakeryShortCodesContainer {
		}
	}
	vc_map( array(
        "name" => __("Meshjobs Price List",'meshjobs'),
        "base" => "price_child",
        "class" => "", 
        "category" => __('Content','meshjobs'),
		"as_child" => array('only' => 'price_parent'),
        "params" => array(
		    array(
            "type" => "textfield",
            "holder" => "div",
            "class" => "",
            "heading" => __("List Title",'meshjobs'),
            "param_name" => "price_listtitle",
            "value" => __("",'meshjobs'),
            "description" => __("",'meshjobs'),
            ),
        ) 
    ) );
	vc_map( array(
        "name" => __("Meshjobs Company Directory",'meshjobs'),
        "base" => "meshjobs_directory", 
        "class" => "", 
        "category" => __('Content','meshjobs'),
        "params" => array(
		    array(
            "type" => "alert-box",
            "holder" => "div",
            "class" => "",
			"heading" => __("Note:-",'meshjobs'),
            "param_name" => "directory_note",
            "value" => __("",'meshjobs'),
            "description" => __("All Company Directory",'meshjobs'),
            ),
        )
    ) );
	vc_map( array(
        "name" => __("Meshjobs Recent Companies",'meshjobs'),
        "base" => "meshjobs_companies",
        "class" => "", 
        "category" => __('Content','meshjobs'),
        "params" => array(
		    array(
            "type" => "textfield",
            "holder" => "div",
            "class" => "",
            "heading" => __("Number Of Post",'meshjobs'),
            "param_name" => "companies_no",
            "value" => __("6",'meshjobs'),
            "description" => __("Insert integer Values Here.",'meshjobs'),
            ),
        )
    ) );
	vc_map( array(
        "name" => __("Meshjobs Site Stats",'meshjobs'),
        "base" => "meshjobs_stats", 
        "class" => "", 
        "category" => __('Content','meshjobs'),
        "params" => array(
		    array(
            "type" => "attach_image",
            "holder" => "div",
            "class" => "",
            "heading" => __("Upload Icon Image",'meshjobs'),
            "param_name" => "stats_img", 
            "value" => __("",'meshjobs'),
            "description" => __("Upload Icon Image Here.",'meshjobs')
            ),
			array(
            "type" => "textfield",
            "holder" => "div",
            "class" => "",
            "heading" => __("Numbers",'meshjobs'),
            "param_name" => "stats_numbers",
            "value" => __("",'meshjobs'),
            "description" => __("Integer text Here.",'meshjobs')
            ),
		    array(
            "type" => "textfield",
            "holder" => "div",
            "class" => "",
            "heading" => __("Title",'meshjobs'),
            "param_name" => "stats_title",
            "value" => __("",'meshjobs'),
            "description" => __("Title text Here.",'meshjobs'),
            ),
        )
    ) );
	vc_map( array(
        "name" => __("Meshjobs Video Details",'meshjobs'),
        "base" => "meshjobs_video", 
        "class" => "", 
        "category" => __('Content','meshjobs'),
        "params" => array(
		    array(
            "type" => "textfield",
            "holder" => "div",
            "class" => "",
            "heading" => __("Title",'meshjobs'),
            "param_name" => "video_title",
            "value" => __("",'meshjobs'),
            "description" => __("Title text Here.",'meshjobs'),
            ),
		    array(
            "type" => "textfield",
            "holder" => "div",
            "class" => "",
            "heading" => __("Subtitle",'meshjobs'),
            "param_name" => "video_subtitle",
            "value" => __("",'meshjobs'),
            "description" => __("Subtitle text Here.",'meshjobs')
            ),
			array(
            "type" => "vc_link",
            "holder" => "div",
            "class" => "",
            "heading" => __("Edit Button",'meshjobs'),
            "param_name" => "video_link",
            "value" => __("",'meshjobs'),
            "description" => __("Edit Button Here.",'meshjobs')
            ),
			array(
            "type" => "textfield",
            "holder" => "div",
            "class" => "",
            "heading" => __("Enter URL Vimeo Or Youtube",'meshjobs'),
            "param_name" => "video_url",
            "value" => __("",'meshjobs'),
            "description" => __("Video URL Here.",'meshjobs'),
            ),
			array(
            "type" => "attach_image",
            "holder" => "div",
            "class" => "",
            "heading" => __("Upload video Overlay Image",'meshjobs'),
            "param_name" => "video_overlay", 
            "value" => __("",'meshjobs'),
            "description" => __("Upload Overlay Image Here.",'meshjobs')
            ),
			array(
            "type" => "textarea_html",
            "holder" => "div",
            "class" => "",
            "heading" => __("video Description",'meshjobs'),
            "param_name" => "content",
            "value" => __("",'meshjobs'),
            "description" => __("Description text Here.",'meshjobs'),
            ),
        )
    ) );
	vc_map( array(
        "name" => __("Meshjobs App Details",'meshjobs'),
        "base" => "meshjobs_app", 
        "class" => "", 
        "category" => __('Content','meshjobs'),
        "params" => array(
		    array(
            "type" => "attach_image",
            "holder" => "div",
            "class" => "",
            "heading" => __("Upload Background Image",'meshjobs'),
            "param_name" => "app_bg_img", 
            "value" => __("",'meshjobs'),
            "description" => __("Upload BG Image Here.",'meshjobs')
            ),
		    array(
            "type" => "textarea_html",
            "holder" => "div",
            "class" => "",
            "heading" => __("Title",'meshjobs'),
            "param_name" => "content",
            "value" => __("",'meshjobs'),
            "description" => __("Title text Here.",'meshjobs'),
            ),
		    array(
            "type" => "textfield",
            "holder" => "div",
            "class" => "",
            "heading" => __("Subtitle",'meshjobs'),
            "param_name" => "app_subtitle",
            "value" => __("",'meshjobs'),
            "description" => __("Subtitle text Here.",'meshjobs')
            ),
			array(
            "type" => "attach_image",
            "holder" => "div",
            "class" => "",
            "heading" => __("Upload Image",'meshjobs'),
            "param_name" => "app_img", 
            "value" => __("",'meshjobs'),
            "description" => __("Upload Image Here.",'meshjobs')
            ),
			array(
            "type" => "vc_link",
            "holder" => "div",
            "class" => "",
            "heading" => __("Edit Button",'meshjobs'),
            "param_name" => "app_link",
            "value" => __("",'meshjobs'),
            "description" => __("Edit Button Here.",'meshjobs')
            ),
        )
    ) );
	vc_map( array(
        "name" => __("Meshjobs Bottom Section",'meshjobs'),
        "base" => "meshjobs_bottom", 
        "class" => "", 
        "category" => __('Content','meshjobs'),
        "params" => array(
		    array(
            "type" => "textarea",
            "holder" => "div",
            "class" => "",
            "heading" => __("Description",'meshjobs'),
            "param_name" => "bottom_content",
            "value" => __("",'meshjobs'),
            "description" => __("Description text Here.",'meshjobs'),
            ),
			array(
            "type" => "vc_link",
            "holder" => "div",
            "class" => "",
            "heading" => __("First Button",'meshjobs'),
            "param_name" => "bottom_first",
            "value" => __("",'meshjobs'),
            "description" => __("Edit Button Here.",'meshjobs')
            ),
		    array(
            "type" => "vc_link",
            "holder" => "div",
            "class" => "",
            "heading" => __("Second Button",'meshjobs'),
            "param_name" => "bottom_second",
            "value" => __("",'meshjobs'),
            "description" => __("Edit Button Here.",'meshjobs')
            ),
        )
    ) );	
}
?>