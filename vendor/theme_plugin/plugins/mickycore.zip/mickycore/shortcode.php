<?php
//********************** shortcode Heading **************************//
add_shortcode( 'meshjobs_heading', 'meshjobs_heading_func' );
function meshjobs_heading_func($atts) { // New function parameter $content is added!
    extract( shortcode_atts( array(
        'heading_title' => '',
        'heading_subtitle' => ''
    ), $atts ) );
	
    $result = '';
	$result .= '<div class="row">
		<div class="col-lg-8 col-md-8 col-sm-12 col-xs-12 col-lg-offset-2 col-md-offset-2 col-sm-offset-0 col-xs-offset-0">
			<div class="mj_mainheading mj_toppadder80 mj_bottompadder50">
				<h1>'.esc_html($heading_title).'</h1>
				<p>'.esc_html($heading_subtitle).'</p>
			</div>
		</div>
    </div>';
	return $result;
}
//*********************** shortcode padding ****************************//
add_shortcode( 'meshjobs_padding', 'meshjobs_padding_func' );
function meshjobs_padding_func($atts) { // New function parameter $content is added!
    extract( shortcode_atts( array(
      'meshjobs_padding' => '50px'
    ), $atts ) );
    $result = '';
	$result .= '<div style="padding: '.esc_attr($meshjobs_padding).'; float: left; width: 100%;"></div>';
	return $result;
}
//********************** shortcode Banner **************************//
add_shortcode( 'meshjobs_banner', 'meshjobs_banner_func' );
function meshjobs_banner_func($atts) { // New function parameter $content is added!
    extract( shortcode_atts( array(
        'banner_img' => '',
        'banner_title' => '',
        'banner_subtitle' => ''
    ), $atts ) );
	
    $result = '';
    $src = '';
	$src  = wp_get_attachment_image_src($banner_img ,'full');
    if(!empty($src))
    {
	 $src  = $src[0];
	 $thumb_w = '1263';
	 $thumb_h = '280';
	 $image = meshjobs_resize($src, $thumb_w, $thumb_h, true);
	}
	$result .= '<div class="mj_pagetitle">
        <img src="'.esc_url($image).'" alt="">
		<div class="mj_mainheading_overlay"></div>
        <div class="mj_pagetitle_inner">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        <div class="mj_mainheading mj_toppadder80 mj_bottompadder80">
                            <h1>'.esc_html($banner_title).'</h1>
                            <p>'.esc_html($banner_subtitle).'</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>';
	return $result;
}
//********************** shortcode Gallery **************************//
add_shortcode( 'meshjobs_gallery', 'meshjobs_gallery_func' );
function meshjobs_gallery_func($atts) { // New function parameter $content is added!
    extract( shortcode_atts( array(
        'gallery_note' => ''
    ), $atts ) );
	global $post;
    $result = '';
	$result .= '<div class="row">
		<div class="col-lg-12 col-md-12 col-sm-12">
			<div class="row">
				<div class="mj_filter_menu">';
				$taxonomy ='';
				$tax_terms ='';
				$taxonomy = 'gallery_categories'; 
				$tax_terms = get_terms($taxonomy);
				$args = array(
					'post_type' => 'gallery',
					'taxonomy name here' => 'gallery_categories',
					'numberposts' => -1,
				);
					$result .= '<ul>
					    <li> <a href="#" class="filter" data-filter="all">'.esc_html__('All','meshjobs').'</a>
						</li>';
						foreach($tax_terms as $category){
						$cata_name = $category->name;
						$cata_slug = $category->slug;
						
						$result .= '<li> <a href="#" class="filter" data-filter=".'.esc_attr($cata_slug).'">'.esc_html($cata_name).'</a>
						</li>';
						}
					$result .= '</ul>
				</div>
			</div>
		</div>
		<div id="mj_grid">';
		$args = array( 'post_type' => 'gallery','posts_per_page' => -1);
        $query = new WP_Query( $args );
	    if($query->have_posts()):	
	    while($query->have_posts()) : $query->the_post();
        $ca_slug = array();
        $post_categories = get_the_terms( get_the_ID(), 'gallery_categories' );

        if( $post_categories )
	    {
		    foreach ( $post_categories as $selected_categories ) 
        	{
        	  $ca_slug[] = $selected_categories->slug;
        	  $post_cata_slug = join(" ",$ca_slug);		  
        	}
        }
		else
		{
		$post_cata_slug = '';
		}	
		$original_image = wp_get_attachment_url( get_post_thumbnail_id( get_the_ID() ) , 'full' );
		$thumb_w = '390';
		$thumb_h = '240';
		$image = meshjobs_resize($original_image, $thumb_w, $thumb_h, true);
			$result .= '<div class="col-lg-4 col-md-4 col-sm-4 col-xs-6 mix mix-all '. $post_cata_slug .'" data-value="1">
				<div class="row">
					<div class="mj_gallary_img">
						<img src="'.esc_url($image).'" alt="gallery" class="img-responsive">
						<div class="mj_overlay">
							<div class="mj_gallary_info">
								<h5 class="animated fadeInDown"><a class="fancybox" data-fancybox-group="gallery" href="'.esc_url($original_image).'" title="'.esc_html(get_the_content()).'">'.esc_html(get_the_title()).'</a></h5>
								<p class="animated fadeInUp">'.esc_html($post_categories[0]->name) .'</p>
							</div>
						</div> 
					</div>
				</div>
			</div>';
			endwhile;   
	        endif;
	        wp_reset_postdata();
		$result .= '</div>
    </div>
	<div class="mj_bottompadder40">
	</div>';
	return $result;
}
//********************** shortcode Team **************************//
add_shortcode( 'meshjobs_team', 'meshjobs_team_func' );
function meshjobs_team_func($atts) { // New function parameter $content is added!
    extract( shortcode_atts( array(
        'team_note' => ''
    ), $atts ) );
	global $post;
    $result = '';
	$result .= '<div class="row">
		<div class="col-lg-12 col-md-12 col-sm-12">
			<div class="mj_team_filter_menu mj_toppadder10 mj_bottompadder60">';
			$taxonomy ='';
			$tax_terms ='';
			$taxonomy = 'team_categories'; 
			$tax_terms = get_terms($taxonomy);
			$args = array(
				'post_type' => 'team',
				'taxonomy name here' => 'team_categories',
				'numberposts' => -1,
			);
				$result .= '<ul>
					<li> <a href="#" class="filter" data-filter="all">'.esc_html__('All','meshjobs').'</a>
					</li>';
					foreach($tax_terms as $category){
					$cata_name = $category->name;
					$cata_slug = $category->slug;
					$result .= '<li> <a href="#" class="filter" data-filter=".'.esc_html($cata_slug).'">'.esc_html($cata_name).'</a>
					</li>';
					}
				$result .= '</ul>
			</div>
		</div>
		<div id="mj_grid">';
		$args = array( 'post_type' => 'team','posts_per_page' => -1);
        $query = new WP_Query( $args );
	    if($query->have_posts()):	
	    while($query->have_posts()) : $query->the_post();
        $ca_slug = array();
        $post_categories = get_the_terms( get_the_ID(), 'team_categories' );
		$meshjobs_team_name = get_post_meta($post->ID,'meshjobs_team_name',true);
		$meshjobs_team_image = get_post_meta($post->ID,'meshjobs_team_image',true);
		$meshjobs_team_decription = get_post_meta($post->ID,'meshjobs_team_decription',true);
		$facebook = get_post_meta($post->ID,'meshjobs_team_Facebook',true);	
		$facebook_show = get_post_meta($post->ID,'meshjobs_team_Facebook_show',true);
		$twitter = get_post_meta($post->ID,'meshjobs_team_Twitter',true);	
		$twitter_show = get_post_meta($post->ID,'meshjobs_team_Twitter_show',true);	
		$youtube = get_post_meta($post->ID,'meshjobs_team_youtube',true);	
		$youtube_show = get_post_meta($post->ID,'meshjobs_team_youtube_show',true);
		$linkedin = get_post_meta($post->ID,'meshjobs_team_linkedin',true);	
		$linkedin_show = get_post_meta($post->ID,'meshjobs_team_linkedin_show',true);
		$googleplus = get_post_meta($post->ID,'meshjobs_team_googleplus',true);	
		$googleplus_show = get_post_meta($post->ID,'meshjobs_team_googleplus_show',true);	
		$dribbble = get_post_meta($post->ID,'meshjobs_team_dribbble',true);	
		$dribbble_show = get_post_meta($post->ID,'meshjobs_team_dribbble_show',true);
		$behance = get_post_meta($post->ID,'meshjobs_team_behance',true);	
		$behance_show = get_post_meta($post->ID,'meshjobs_team_behance_show',true);
		
        if( $post_categories )
	    {
		    foreach ( $post_categories as $selected_categories ) 
        	{
        	  $ca_slug[] = $selected_categories->slug;
        	  $post_cata_slug = join(" ",$ca_slug);		  
        	}
        }
		else
		{
		$post_cata_slug = '';
		}
		$thumb_w = '170';
		$thumb_h = '170';
		$image = meshjobs_resize($meshjobs_team_image, $thumb_w, $thumb_h, true);
			$result .= '<div class="col-lg-4 col-md-4 col-sm-6 col-xs-12 mix mix-all '. $post_cata_slug .'" data-value="1">
				<div class="mj_team_wrapper">
					<div class="mj_team_img">
						<img src="'.esc_url($image).'" alt="team">
					</div>
					<div class="mj_team_info mj_toppadder80">
						<span class="animated fadeInUp mj_toppadder20">'.esc_html($post_categories[0]->name) .'</span>
						<h4 class="animated fadeInDown"><a>'.esc_html($meshjobs_team_name).'</a></h4>
						<p>'.esc_html($meshjobs_team_decription).'</p>
						<ul>';
						if(!empty($facebook) && $facebook_show == 'facebook') 
						{
							$result .= '<li><a href="'.esc_url($facebook).'"><i class="fa fa-facebook"></i></a>
							</li>';
						}
						if(!empty($twitter) && $twitter_show == 'twitter') 
						{
							$result .= '<li><a href="'.esc_url($twitter).'"><i class="fa fa-twitter"></i></a>
							</li>';
						}
						if(!empty($youtube) && $youtube_show == 'youtube') 
						{
							$result .= '<li><a href="'.esc_url($youtube).'"><i class="fa fa-youtube"></i></a>
							</li>';
						}
						if(!empty($linkedin) && $linkedin_show == 'Linkedin') 
						{
							$result .= '<li><a href="'.esc_url($linkedin).'"><i class="fa fa-linkedin"></i></a>
							</li>';
						}
						if(!empty($googleplus) && $googleplus_show == 'Googleplus') 
						{
							$result .= '<li><a href="'.esc_url($googleplus).'"><i class="fa fa-google-plus"></i></a>
							</li>';
						}
						if(!empty($dribbble) && $dribbble_show == 'dribbble') 
						{
							$result .= '<li><a href="'.esc_url($dribbble).'"><i class="fa fa-dribbble"></i></a>
							</li>';
						}
						if(!empty($behance) && $behance_show == 'Behance') 
						{
							$result .= '<li><a href="'.esc_url($behance).'"><i class="fa fa-behance"></i></a>
							</li>';
						}
							
						$result .= '</ul>
					</div>
				</div>
			</div>';
			endwhile;   
	        endif;
	        wp_reset_postdata();
			
			$result .= '<div class="clearfix"></div>
		</div>
    </div>';
	return $result;
}
//********************** shortcode Work **************************//
add_shortcode( 'meshjobs_work', 'meshjobs_work_func' );
function meshjobs_work_func($atts) { // New function parameter $content is added!
    extract( shortcode_atts( array(
        'work_pattern' => '1',
        'work_title' => '',
        'work_img' => '',
        'work_description' => '',
        'work_read_more' => '',
    ), $atts ) );
	global $post;
    $result = '';
	$href = '';
    $href = vc_build_link( $work_read_more );
    $src = '';
	if($work_pattern=='1'){
	$src  = wp_get_attachment_image_src($work_img ,'full');
    if(!empty($src))
    {
	 $src  = $src[0];
	 $thumb_w = '170';
	 $thumb_h = '106';
	 $image = meshjobs_resize($src, $thumb_w, $thumb_h, true);
	}
	$result .= '<div class="mj_recent_workit text-center">
		<div class="mj_workit_innerheader">
			<h4>'.esc_html($work_title).'</h4>
		</div>
		<div class="mj_workit_info">
			<img src="'.esc_url($image).'" class="img-responsive" alt="">
			<p class="mj_toppadder50">'.esc_html($work_description).'</p>
		</div>
		<div class="mj_workit_innerfooter">
			<a href="'.esc_url($href['url']).'" target="'.esc_attr($href['target']).'">'.esc_html($href['title']).'</a>
		</div>
    </div>';
	} if($work_pattern=='2'){
	$src  = wp_get_attachment_image_src($work_img ,'full');
    if(!empty($src))
    {
	 $src  = $src[0];
	 $thumb_w = '170';
	 $thumb_h = '213';
	 $image = meshjobs_resize($src, $thumb_w, $thumb_h, true);
	}
	$result .= '<div class="mj_recent_workit">
	<div class="mj_workit_innerheader">
		<h4>'.esc_html($work_title).'</h4>
	</div>
	<div class="mj_workit_info">
		<div class="row">
			<div class="col-lg-3 col-md-3 col-sm-12 col-xs-12 text-center">
				<img src="'.esc_url($image).'" class="img-responsive" alt="">
			</div>
			<div class="col-lg-9 col-md-9 col-sm-12 col-xs-12">
				<p class="mj_toppadder40">'.esc_html($work_description).'</p>
			</div>
		</div>
	</div>
	<div class="mj_workit_innerfooter text-center">
		<a href="'.esc_url($href['url']).'" target="' . esc_attr($href['target']) . '">'.esc_html($href['title']).'</a>
	</div>
    </div>';
	}
	return $result;
}
//********************** shortcode Articals **************************//
add_shortcode( 'meshjobs_articals', 'meshjobs_articals_func' );
function meshjobs_articals_func($atts) { // New function parameter $content is added!
    extract( shortcode_atts( array(
        'articals_no' => '6',
    ), $atts ) );
	
    $result = '';
	global $post;
	$result .= '<div class="row">
		<div class="mj_articleslider mj_bottompadder50">
			<div class="owl-carousel owl-theme">';
			$blog_query = new WP_Query( array( 'post_type'=>'post','posts_per_page' => $articals_no )); 
	        if ($blog_query->have_posts()): while ($blog_query->have_posts()) : $blog_query->the_post();
			$meshjobs_thumb = get_post_thumbnail_id($post->ID);
			$meshjobs_attachment_url = wp_get_attachment_url($meshjobs_thumb, 'full');
			$meshjobs_thumb_w ='360';
			$meshjobs_thumb_h ='242';
			if(!empty($meshjobs_thumb)) {
				$meshjobs_image = meshjobs_resize($meshjobs_attachment_url, $meshjobs_thumb_w, $meshjobs_thumb_h, true);
			}else{
				$meshjobs_image = get_template_directory_uri().'/images/no_image.jpg'; 
			}
				$result .= '<div class="item">
					<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
						<div class="mj_recent_article">
							<div class="mj_articleimg">
								<img src="'.esc_url($meshjobs_image).'" class="img-responsive" alt="">
								<div class="mj_articleoverlay">
									<p><a href="'.esc_url(get_permalink()).'">'.esc_attr(get_the_title()).'</a></p>
								</div>
							</div>
							<div class="mj_articledata">
								<p>'.esc_html(get_the_excerpt()).'</p>
								<span><a href="'.esc_url(get_permalink()).'">'.esc_attr(get_the_time('F j, Y')).'</a></span>
								<a href="'.esc_url( get_permalink() ).'"><i class="fa fa-angle-right"></i></a>
							</div>
						</div>
					</div>
				</div>';
			endwhile; endif;  
            wp_reset_postdata();
				
			$result .= '</div>
		</div>
	</div>';
	return $result;
}
//****************** shortcode Bottom section *******************//
add_shortcode( 'meshjobs_bottom', 'meshjobs_bottom_func' );
function meshjobs_bottom_func($atts) { // New function parameter $content is added!
    extract( shortcode_atts( array(
        'bottom_content' => '',
        'bottom_first' => '',
        'bottom_second' => ''
    ), $atts ) );
	
    $result = '';
	$href = '';
	$href1 = '';
    $href = vc_build_link( $bottom_first );
    $href1 = vc_build_link( $bottom_second );
	$result .= '<div class="mj_bluebg mj_toppadder80 mj_bottompadder80">
    <div class="container">
        <div class="row">
		<div class="col-lg-8 col-md-8 col-sm-12 col-xs-12 col-lg-offset-2 col-md-offset-2 col-sm-offset-0 col-xs-offset-0">
		<div class="mj_addsection">
			<h2>'.esc_html($bottom_content).'</h2>
			<ul>
				<li><a href="'.esc_url($href['url']).'" class="mj_mainbtn mj_btnyellow" data-text="'.esc_html($href['title']).'" target="' .esc_attr($href['target']). '"><span>'.esc_html($href['title']).'</span></a>
				</li>

				<li><a href="'.esc_url($href1['url']).'" class="mj_mainbtn mj_btndefault" data-text="'.esc_html($href1['title']).'" target="' .esc_attr($href1['target']). '"><span>'.esc_html($href1['title']).'</span></a>
				</li>
			</ul>
		</div>
		</div>
		</div>
	</div>
    </div>';
	return $result;
}
//********************* shortcode App Details  ******************//
add_shortcode( 'meshjobs_app', 'meshjobs_app_func' );
function meshjobs_app_func($atts,$content = null) { // New function parameter $content is added!
    extract( shortcode_atts( array(
      'app_bg_img'   => '',
      'app_title'    => '',
      'app_subtitle' => '',
      'app_img'      => '',
      'app_link'     => ''
    ), $atts ) );
	$content = wpb_js_remove_wpautop($content, true);
	$pattern = "=^<p>(.*)</p>$=i";
    preg_match($pattern, $content, $matches);
    $result = '';
    $src = '';
    $src1 = '';
	$href = '';
    $href = vc_build_link( $app_link );
	$src  = wp_get_attachment_image_src($app_bg_img ,'full');
    if(!empty($src))
    {
	 $src  = $src[0];
	 $thumb_w = '1400';
	 $thumb_h = '800';
	 $image = meshjobs_resize($src, $thumb_w, $thumb_h, true);
	}
	$src1  = wp_get_attachment_image_src($app_img ,'full');
    if(!empty($src1))
    {
	 $src1  = $src1[0];
	 $thumb_w = '750';
	 $thumb_h = '413';
	 $image1 = meshjobs_resize($src1, $thumb_w, $thumb_h, true);
	}
	$result .= '<div class="mj_mockup_section mj_toppadder70" style="background: url('.esc_url($image).');">
        <div class="mj_overlay"></div>
        <div class="container">
            <div class="row">
                <div class="col-lg-8 col-md-8 col-sm-12 col-xs-12 col-lg-offset-2 col-md-offset-2 col-sm-offset-0 col-xs-offset-0">
                    <div class="mj_mainheading mj_whiteheading mj_toppadder50 mj_bottompadder50">
                        <h1>'.$matches[1].'</h1>
                        <p>'.esc_html($app_subtitle).'</p>
                    </div>
                </div> 
                <div class="col-lg-8 col-md-8 col-sm-12 col-xs-12 col-lg-offset-2 col-md-offset-2 col-sm-offset-0 col-xs-offset-0">
                    <div class="mj_iphonemockup">
                        <img src="'.esc_url($image1).'" class="img-responsive" alt="">
                    </div>
                </div>
            </div>
        </div>
    </div>
	<div class="mj_lightgraytbg mj_bottompadder80">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="mj_showmore"><a href="'.esc_url($href['url']).'" class="mj_showmorebtn mj_bigbtn mj_greenbtn" target="' . esc_attr($href['target']). '">'.esc_html($href['title']).'</a>
                    </div>
                </div>
			</div>
		</div>
	</div>';
	return $result;
}
//********************* shortcode Video Details  ******************//
add_shortcode( 'meshjobs_video', 'meshjobs_video_func' );
function meshjobs_video_func($atts,$content = null) { // New function parameter $content is added!
    extract( shortcode_atts( array(
      'video_title'   => '',
      'video_subtitle'    => '',
      'video_link' => '',
      'video_url'      => '',
      'video_overlay'     => ''
    ), $atts ) );
	$content = wpb_js_remove_wpautop($content, true);
	$pattern = "=^<p>(.*)</p>$=i";
    preg_match($pattern, $content, $matches);
    $result = '';
    $src = '';
	$href = '';
    $href = vc_build_link( $video_link );
	$src  = wp_get_attachment_image_src($video_overlay ,'full');
    if(!empty($src))
    {
	 $src  = $src[0];
	 $thumb_w = '632';
	 $thumb_h = '505';
	 $image = meshjobs_resize($src, $thumb_w, $thumb_h, true);
	}
	$result .= '<div class="mj_transprentbg">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                    <div class="row">
                        <div class="col-lg-10 col-md-10 col-sm-12 col-xs-12 col-lg-offset-1 col-md-offset-1 col-sm-offset-0 col-xs-offset-0 mj_toppadder80 mj_bottompadder50">
                            <div class="mj_videosection_data mj_toppadder50">
                                <h1>'.esc_html($video_title).'</h1>
                                <p>'.esc_html($video_subtitle).'</p>
                                <a href="'.esc_url($href['url']).'" class="mj_readmore" target="' . esc_attr($href['target']). '">'.esc_html($href['title']).'</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                    <div class="row">
                        <div class="mj_video">
                            <div class="mj_videodiv">
                                <img src="'.esc_url($image).'" alt="work">
                                <div class="mj_overlay">
                                    <div class="mj_videooverlay_inner">
                                        <a href="#"><i class="fa fa-play-circle"></i></a>
                                        <p>'.$matches[1].'</p>
                                    </div>
                                </div>
                            </div>
                            <iframe id="video" src="'.esc_url($video_url).'" width="1200" height="482"></iframe>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>';
	return $result;
}
//********************* shortcode Site Stats  ******************//
add_shortcode( 'meshjobs_stats', 'meshjobs_stats_func' );
function meshjobs_stats_func($atts) { // New function parameter $content is added!
    extract( shortcode_atts( array(
      'stats_img'   => '',
      'stats_numbers'    => '',
      'stats_title' => '',
    ), $atts ) );
    $result = '';
    $src = '';
	$src  = wp_get_attachment_image_src($stats_img ,'full');
    if(!empty($src))
    {
	 $src  = $src[0];
	 $thumb_w = '70';
	 $thumb_h = '75';
	 $image = meshjobs_resize($src, $thumb_w, $thumb_h, true);
	}
	$result .= '<div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
		<div class="mj_countdiv">
			<div class="mj_count_img">
				<img src="'.esc_url($image).'" class="img-responsive" alt="">
			</div>
			<div class="mj_countdata">
				<span class="timer" data-from="0" data-to="'.esc_attr($stats_numbers).'" data-speed="3000" data-decimals="3"></span>
				<p>'.esc_html($stats_title).'</p>
			</div>
		</div>
	</div>';
	return $result;
}
//*************** shortcode Testimonial Parent ******************//
add_shortcode( 'testimonial_parent', 'meshjobs_testimonial_parent_func' );
function meshjobs_testimonial_parent_func($atts,$content = null) { // New function parameter $content is added!
    extract( shortcode_atts( array(
	  'testimonial_bg_img' => '', 
	  'testimonial_description' => '', 
    ), $atts ) );
    $result = ''; 
	
	$src = $qut = '';
	$src  = wp_get_attachment_image_src($testimonial_bg_img ,'full');
    if(!empty($src))
    {
	 $src  = $src[0];
	 $thumb_w = '632';
	 $thumb_h = '505';
	 $image = meshjobs_resize($src, $thumb_w, $thumb_h, true);
	}
	$qut = get_template_directory_uri().'/images/quote.png';
	$result .= '<div class="mj_transprentbg">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                    <div class="row">
                        <div class="mj_videodiv">
                            <img src="'.esc_url($image).'" alt="">
                            <div class="mj_overlay">
                                <div class="mj_overlay_inner">
                                    <h1>'.esc_html($testimonial_description).'</h1>
                                </div>
                            </div>

                        </div>

                    </div>
                </div>
                <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                    <div class="row">
                        <div class="mj_testimonial_slider">
                            <span class="mj_quote"><img src="'.esc_url($qut).'" class="img-responsive" alt=""></span>
                            <div class="mj_testimonial_slider_content">
                                <div id="owl-demo" class="owl-carousel owl-theme">'.do_shortcode($content).'
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>';
	return $result;
}
//*************** shortcode Testimonial Child *****************//
add_shortcode( 'testimonial_child', 'meshjobs_testimonial_child_func' );
function meshjobs_testimonial_child_func($atts,$content = null) { // New function parameter $content is added!
    extract( shortcode_atts( array(
	  'testimonial_img' => '', 
	  'testimonial_content' => '', 
	  'testimonial_name' => '', 
	  'testimonial_designation' => '', 
    ), $atts ) );
    $result = ''; 
	
	$src = '';
	$src  = wp_get_attachment_image_src($testimonial_img ,'full');
    if(!empty($src))
    {
	 $src  = $src[0];
	 $thumb_w = '120';
	 $thumb_h = '120';
	 $image = meshjobs_resize($src, $thumb_w, $thumb_h, true);
	}
	$result .= '<div class="item">
		<div class="mj_testimonial_img">
			<img src="'.esc_url($image).'" class="img-responsive" alt="">
		</div>
		<div class="mj_testimonial_data">
			<h4>'.esc_html($testimonial_content).'</h4>
			<h6>'.esc_html($testimonial_name).'</h6>
			<p>'.esc_html($testimonial_designation).'</p>
		</div>
    </div>';
	return $result;
}
//*************** shortcode Price Parent ******************//
add_shortcode( 'price_parent', 'meshjobs_price_parent_func' );
function meshjobs_price_parent_func($atts,$content = null) { // New function parameter $content is added!
    extract( shortcode_atts( array(
	  'price_color' => '1', 
	  'price_no' => '$50', 
	  'price_title' => 'free', 
	  'price_subtitle' => 'For 1 job listed for 30 days', 
	  'price_link' => '', 
    ), $atts ) );
    $result = ''; 
	$href = '';
    $href = vc_build_link( $price_link );
	$result .= '<div class="mj_pricingtable';
    if($price_color=='1'){$result .= ' mj_greentable';}    
    if($price_color=='2'){$result .= ' mj_bluetable';}    
    if($price_color=='3'){$result .= ' mj_yellowtable';}    
    if($price_color=='4'){$result .= ' mj_orangetable';} 
	$result .= '">
		<div class="mj_pricing_heading">
			<div class="mj_table_price">'.esc_html($price_no).'</div>
			<h3>'.esc_html($price_title).'</h3>
			<span>'.esc_html($price_subtitle).'</span>
		</div>
		<ul>'.do_shortcode($content).'</ul>
		<div class="mj_pricing_footer">
			<a href="'.esc_url($href['url']).'" target="'.esc_attr($href['target']).'"><i class="fa fa-plus"></i> '.esc_html($href['title']).'</a>
		</div>
    </div>';
	return $result;
}
//*************** shortcode Price Child *****************//
add_shortcode( 'price_child', 'meshjobs_price_child_func' );
function meshjobs_price_child_func($atts,$content = null) { // New function parameter $content is added!
    extract( shortcode_atts( array(
	  'price_listtitle' => '',
    ), $atts ) );
    $result = ''; 
	
	$result .= '<li>'.esc_html($price_listtitle).'</li>';
	return $result;
}
//********************** shortcode Directory **************************//
add_shortcode( 'meshjobs_directory', 'meshjobs_directory_func' );
function meshjobs_directory_func($atts) { // New function parameter $content is added!
    extract( shortcode_atts( array(
        'directory_note' => '',
    ), $atts ) );
	
    $result = '';
	$result .= do_shortcode("<pre>[job_manager_companies]</pre>");
	return $result;
}
//********************** shortcode Recent Jobs **************************//
add_shortcode( 'meshjobs_recentjob', 'meshjobs_recentjob_func' );
function meshjobs_recentjob_func($atts) { // New function parameter $content is added!
    extract( shortcode_atts( array(
        'recentjob_no' => '8',
        'recentjob_note' => '',
    ), $atts ) );
	global $post;
    $result = '';
	$result .= '<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
		<div class="mj_tabs mj_bottompadder50">
			<!-- Nav tabs -->
			<ul class="nav nav-tabs mj_joblist" role="tablist">
				<li role="presentation" class="active"><a href="#recentjobs" aria-controls="recentjobs" role="tab" data-toggle="tab">'. esc_html__('Recent Jobs','meshjobs').'</a>
				</li>
			</ul>
			<!-- Tab panes -->
			<div class="tab-content">
				<div role="tabpanel" class="tab-pane active" id="recentjobs">
					<div id="div1" class="mj_tabcontent mj_toppadder30">
						<table class="table table-striped">';
						$job_query = new WP_Query($args = array( 'post_type'=>'job_listing','posts_per_page' => $recentjob_no ));
						if ($job_query->have_posts()): while ($job_query->have_posts()) : $job_query->the_post();
						
						$meshjobs_attachment_url_logo = wp_get_attachment_url( get_post_thumbnail_id( get_the_ID() ) , 'full' );
						$meshjobs_thumb_logow ='70';
						$meshjobs_thumb_logoh ='70';
						$meshjobs_company_logo = meshjobs_resize($meshjobs_attachment_url_logo, $meshjobs_thumb_logow, $meshjobs_thumb_logoh, true); 
						$meshjobs_company_name = get_post_meta($post->ID,'_company_name',true);
						$meshjobs_company_loc = get_post_meta($post->ID,'geolocation_city',true);
						$meshjobs_job_salary = get_post_meta($post->ID,'_job_salary',true);
						$ca_slug = array();
						$post_categories = get_the_terms( get_the_ID(), 'job_listing_type' );
						
						$job_type_slug = get_the_job_type() ? sanitize_title( get_the_job_type()->slug ) : '';
						$job_type_color = get_option( 'job_manager_job_type_'.$job_type_slug.'_color'); 
						
						
						$what = 'background' == get_option( 'job_manager_job_type_what_color' ) ? 'background-color' : 'color';
						
						if( $post_categories )
						{
							foreach ( $post_categories as $selected_categories ) 
							{
							  $ca_slug[] = $selected_categories->slug;
							  $post_cata_slug = join(" ",$ca_slug);		  
							}
						}
						else
						{
						$post_cata_slug = '';
						}
							$result .= '<tr>
								<td><a href="'.esc_url(get_permalink()).'"><i class="fa fa-heart"></i></a>
								</td>';
								if(!empty($meshjobs_company_logo)){
								$result .= '<td>
									<a href="'.esc_url(get_permalink()).'"><img src="'.esc_url($meshjobs_company_logo).'" class="img-responsive" alt="">
									</a>
								</td>';
								}
								$result .= '<td>
									<h4><a href="'.esc_url(get_permalink()).'">'.esc_html(get_the_title()).'</a></h4>
									<p>'.esc_html($meshjobs_company_name).'</p>
								</td>
								<td> 
									<i class="fa fa-map-marker"></i>
									<P>'.esc_html($meshjobs_company_loc).'</P>
								</td>
								<td>
									<a href="'.esc_url(get_permalink()).'"';
                                    if($what == 'background-color'){$result .= ' class="mj_btn mj_greenbtn"';
									$result .= ' style="background-color: '.$job_type_color;}else{
										$result .= ' class="mj_btn" style="color: '.$job_type_color.';"';
									}                                    

									$result .= '">'.esc_html($post_categories[0]->name) .'</a>
								</td>
								<td><span>'.esc_html($meshjobs_job_salary).'</span>
								</td>
							</tr>';
						endwhile; endif;  
                        wp_reset_postdata();
						$result .= '</table>
					</div>';
					$job_query1 = new WP_Query($args1 = array( 'post_type'=>'job_listing','posts_per_page' => -1 ));
					$post_count1 = count( get_posts( $args1 ) );
					if($post_count1 > 6){
					$result .= '<div class="col-lg-4 col-md-4 col-sm-12 col-xs-12 col-lg-offset-4 col-md-offset-4 ajxload">
						<div class="mj_showmore">
							<a id="em_sub" class="mj_blackbtn mj_showmorebtn ajxload">'.esc_html__('Show More','restored').'</a>
							<input type="hidden" value="'. MESHJOBS_AJAX_URL .'"  id="meshjobs_ajaxurl_id">
							<input type="hidden" class="ajx_new"  value="1" />';
						$result .= '</div>
					</div>';
					}else{
						$result .= '<div class="col-lg-4 col-md-4 col-sm-12 col-xs-12 col-lg-offset-4 col-md-offset-4 ajxload">
						<div class="mj_showmore">
							<a id="" class="mj_blackbtn mj_showmorebtn ajxload">'.esc_html__('No More Jobs','restored').'</a>';
						$result .= '</div>
					</div>';
					}
					
				$result .= '</div>
			</div>
		</div>
    </div>';
	return $result;
}
//********************** shortcode Featured Companies **************************//
add_shortcode( 'meshjobs_companies', 'meshjobs_companies_func' );
function meshjobs_companies_func($atts) { // New function parameter $content is added!
    extract( shortcode_atts( array(
        'companies_no' => '6'
    ), $atts ) );
	
    $result = '';
	global $wpdb;
	$companies   = $wpdb->get_col(
		"SELECT p.ID FROM {$wpdb->postmeta} pm
		 LEFT JOIN {$wpdb->posts} p ON p.ID = pm.post_id
		 WHERE pm.meta_key = '_company_name'
		 AND p.post_status = 'publish'
		 AND p.post_type = 'job_listing'
		 GROUP BY pm.meta_value
		 ORDER BY pm.meta_key DESC"
	);
	rsort($companies);
	$count = count($companies);
	if($count>=$companies_no){
		$companies_count = $companies_no;
	}else{
		$companies_count = $count;
	}
	for($i =0; $i<$companies_count; $i++){
	$company_name =  get_post_meta($companies[$i], '_company_name', true );
	$comany_logo = wp_get_attachment_url( get_post_thumbnail_id( $companies[$i] ) , 'full' );
			
	$count = count( get_posts( array( 'post_type' => 'job_listing', 'meta_key' => '_company_name', 'meta_value' => $company_name, 'nopaging' => true ) ) );
	$meshjobs_logow ='209';
	$meshjobs_logoh ='63';
	$meshjobs_company_logo = meshjobs_resize($comany_logo, $meshjobs_logow, $meshjobs_logoh, true);
	$result .= '<div class="col-lg-3 col-md-3 col-sm-4 col-xs-12 mj_bottompadder50">
		<div class="mj_clientlogo">
			<a href="'.esc_url(meshjobs_company_url($company_name)).'"><img src="'.esc_url($meshjobs_company_logo).'" class="img-responsive" alt="">
			<span>' . esc_html($count).'</span></a>
		</div>
    </div>';
	}
	return $result;
}
?>