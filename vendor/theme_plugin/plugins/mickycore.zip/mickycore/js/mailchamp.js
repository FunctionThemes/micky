jQuery(document).ready(function ($) {
    "use strict";
	
	if($('#mailchimp_subscribe').length){
		$('#mailchimp_subscribe').submit(function(e) {
			e.preventDefault();
			var subc_email = $("#mailchimp_email").val();
			var apikey = $("#mailchimp_api_key").val();
			var listid = $("#mailchimp_list_id").val();
			var ur = ajaxobject.ajaxurl;
			if (!valid_email_address(subc_email))  
			{
				$(".mailchimp_message").html('Please make sure you enter a valid email address.');
			}
			else 
			{  
				$(".mailchimp_message").html("<span style='color:green;'>Almost done, please check your email address to confirmation.</span>"); 
				jQuery.ajax({
						 type : "post",
						 url : ajaxobject.ajaxurl,
						 data : {'action': "meshjobs_mailchimp_footer_subcription", apikey : apikey,listid:listid,subc_email:subc_email},
						
						 success: function(response) {
							 console.log(response);
							if(response=="success"){
								$("#mailchimp_email").val("");
								$(".mailchimp_message").html('<span style="color:green;">You have successfully subscribed to our mailing list.</span>');
							} 
							else 
							{
							  $(".mailchimp_message").html('Please make sure you enter a valid email address.');  
							}
						}
				   });
			}
			return false;
		});
	}
	
});