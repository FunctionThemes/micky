<?php
/*
Plugin Name: mickycore
Plugin URI: http://kamleshyadav.com/micky/mickycore
Description: This plugin create custom post type, widget , shortcode and some meta option.
Version: 1.0.0
Author: Himanshu Mehta - himanshusofttech.com
Author URI: http://himanshusofttech.com/
*/

define('PLUGIN_PATH', plugin_dir_url( __FILE__ ) ); 
define('PLUGIN_PATH_DIR', plugin_dir_path( __FILE__ ) );
define('MICKY_AJAX_URL', admin_url('admin-ajax.php') );
/*================ Admin Enqueue scripts ==================*/
function micky_cpt_widget_adminload_script(){
	wp_enqueue_script('jquery');
	wp_enqueue_script('media-upload');
    wp_enqueue_script('thickbox');
	wp_enqueue_script('admin_customjs', PLUGIN_PATH. '/js/admin.js');
}
add_action('admin_enqueue_scripts','micky_cpt_widget_adminload_script'); 
/*================ Admin Enqueue styles ==================*/
function meshjobs_cpt_widget_adminload_styles(){
	wp_enqueue_style('thickbox');
	wp_enqueue_style('admin_customcss', PLUGIN_PATH. '/css/admin.css');
}
add_action('admin_print_styles','meshjobs_cpt_widget_adminload_styles'); 

//require_once 'meshjobs-custompost.php';
//require_once 'meshjobs-metaboxes.php';
//require_once 'meshjobs-widget.php';
//require_once 'shortcode.php';
/* * Load redux-framework */ 


/* if (file_exists(require_once PLUGIN_PATH_DIR.'admin/framework.php')) {
   require_once PLUGIN_PATH_DIR .'admin/framework.php';
}
if (file_exists(require_once PLUGIN_PATH_DIR.'admin/micky-config.php')) {
   require_once PLUGIN_PATH_DIR .'admin/micky-config.php';
} */


if (defined('FW')):
    // the framework was already included in another place, so this version will be inactive/ignored
else:
    /** @internal */
    function _filter_fw_framework_plugin_directory_uri() {
        return PLUGIN_PATH . '/framework';
    }
    add_filter('fw_framework_directory_uri', '_filter_fw_framework_plugin_directory_uri');

    require dirname(__FILE__) .'/framework/bootstrap.php';
endif;
?>